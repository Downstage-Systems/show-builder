#!/usr/bin/env python3
"""Downstage Show Builder - lay out an ATEM show page in the browser, get a
.companionconfig back.

    python3 tools/show-builder/show-builder.py [--companion HOST:PORT] [--port 8787] [--no-browser]

Buttons are built by the same code as atem-me-kit (tools/atem-me-pages.py),
cloned from Rob's page-8 example (donor-atem-page8.companionconfig), so they
are identical to the kit. Source names are read live from Companion's HTTP
API (read-only). Output is either a single page file (import onto any page)
or a full config export with the page placed on a chosen page number.
"""
import argparse, base64, copy, glob, gzip, importlib.util, json, os, re, subprocess
import threading, time, urllib.parse, urllib.request, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(os.path.dirname(HERE))
DATA = os.environ.get("DOWNSTAGE_DATA")     # set by the native app: its bundle is read-only, user files live here
SHOWS = os.path.join(DATA, "shows") if DATA else os.path.join(PROJECT, "shows")
DOWNLOADS = os.path.expanduser("~/Downloads")
DONOR = os.path.join(HERE, "donor-atem-page8.companionconfig")
AUX_DONOR = os.path.join(HERE, "donor-atem-aux.json")
SS_DONOR = os.path.join(HERE, "donor-atem-ssrc.json")

spec = importlib.util.spec_from_file_location("atem_me_pages", os.path.join(PROJECT, "tools", "atem-me-pages.py"))
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)

EXAMPLE = json.loads(gzip.decompress(open(DONOR, "rb").read()))
import sys
sys.path.insert(0, HERE)
import companion_link  # noqa: E402
KIT = gen.Kit(EXAMPLE, json.load(open(AUX_DONOR)), json.load(open(SS_DONOR)))
ATEM_LABEL = next(iter(EXAMPLE["instances"].values()))["label"]

# SuperSource look keys come from SuperSource Builder exports (../ATEM SS Builder): same smart-key code as
# tools/atem-ss-looks-page.py, macro numbers read by name from the export's SS ANIM.xml
SS_BUILDER = os.path.join(os.path.dirname(PROJECT), "ATEM SS Builder")
if DATA:                                    # the app: the SuperSource Builder's usual folder, if this Mac has one
    SS_BUILDER = os.path.expanduser("~/Documents/Downstage Systems/ATEM SS Builder")
_SSLOOKS = {}


def ss_looks_mod():
    if "mod" not in _SSLOOKS:
        sp = importlib.util.spec_from_file_location("atem_ss_looks_page", os.path.join(PROJECT, "tools", "atem-ss-looks-page.py"))
        m = importlib.util.module_from_spec(sp)
        sp.loader.exec_module(m)
        _SSLOOKS["mod"] = m
    return _SSLOOKS["mod"]


def ss_look_shows():
    """SuperSource Builder exports that carry the SS macros: one entry per look family in a file
    (a switcher can hold a 2-box and a 4-box set): [{name, file, count, looks, labels, macros}]."""
    import xml.etree.ElementTree as ET
    out = []
    files = sorted(glob.glob(os.path.join(SS_BUILDER, "exports", "*", "*SS ANIM.xml")), key=os.path.getmtime, reverse=True)
    files += sorted(glob.glob(os.path.join(SS_BUILDER, "*SS ANIM.xml")), key=os.path.getmtime, reverse=True)
    for f in files:
        try:
            fams = ss_looks_mod().families(f)
        except BaseException:
            continue
        for n in fams:
            try:
                out.append(ss_look_show(f, ET, n))
            except BaseException:                  # read_macros exits on files without the SS macros;
                continue                           # any other odd export is skipped, never fatal
    return out


def ss_look_show(f, ET, count=None):
    if str(count).startswith("F"):                 # rounded + fly-in look: keys per keyer
        fl = ss_looks_mod().read_fly(f, count)
        rel = os.path.relpath(f, SS_BUILDER)
        name = os.path.basename(os.path.dirname(f)) if os.sep in rel else os.path.basename(f).replace(" SS ANIM.xml", "")
        return {"name": f"{name} · rounded fly-in", "file": rel, "count": count, "product": ET.parse(f).getroot().get("product", ""),
                "looks": [fl["home"]] + [f"K{k}" for k, _, _ in fl["keys"]] + ["SETUP"],
                "labels": {f"K{k}": (f"BOX {inp[1]}" if isinstance(inp, tuple) else fl["names"].get(inp) or f"IN {inp}")
                           for k, inp, _ in fl["keys"]},
                "macros": str(fl["setup"])}
    macros, pics, roles = ss_looks_mod().read_macros(f, count)
    n = roles["n"]
    pics = (list(pics) + [b for b in (1, 2, 3, 4) if b not in pics])[:n]   # newer exports may omit the picture boxes
    root = ET.parse(f).getroot()
    short = {i.get("id"): i.get("shortName") for i in root.iter("Input")}
    prefix = ss_looks_mod().PREFIX[n]
    setup = next(m for m in root.iter("Macro") if m.get("name") == f"{prefix}{n}BOX SETUP")
    src = {int(op.get("boxIndex")) + 1: op.get("input", "") for op in setup if op.get("id", "").endswith("BoxInput")}
    def label(box):
        n = src.get(box, "")
        num = n.replace("Camera", "") if n.startswith("Camera") else ""
        return short.get(num) or n or f"BOX {box}"
    rel = os.path.relpath(f, SS_BUILDER)
    name = os.path.basename(os.path.dirname(f)) if os.sep in rel else os.path.basename(f).replace(" SS ANIM.xml", "")
    return {"name": name + ("" if n == 2 else f" · {n} boxes"), "file": rel, "count": n, "product": root.get("product", ""),
            "looks": [f"{n}BOX"] + [f"FS{i + 1}" for i in range(n)] + ["SETUP"],
            "labels": {f"FS{i + 1}": label(b) for i, b in enumerate(pics)},
            "macros": f"{min(macros.values())}-{max(macros.values())}"}


DECKS = {
    # + XL: keys rows 0-3, one touch strip (row 4), encoders on row 5 at DIAL_COLS
    "plusxl": {"name": "Stream Deck + XL", "cols": 9, "rows": 4, "dials": list(gen.DIAL_COLS)},
    "xl": {"name": "Stream Deck XL", "cols": 8, "rows": 4, "dials": []},
    "mk2": {"name": "Stream Deck 15 key", "cols": 5, "rows": 3, "dials": []},
    "neo": {"name": "8 keys (4x2)", "cols": 4, "rows": 2, "dials": []},
    "mini": {"name": "Stream Deck Mini", "cols": 3, "rows": 2, "dials": []},
}
MAX_AUX = 24
CATALOG = {"host": None, "data": None, "at": None}
PREVIEWS = {}                      # (host, conn, preset, vars-json) -> PNG bytes
PREVIEW_POOL = []                  # [(lock, PreviewSource)] - four sockets so a folder fills in parallel
PREVIEW_POOL_LOCK = threading.Lock()


def catalog(refresh=False):
    if refresh or CATALOG["data"] is None or CATALOG["host"] != STATE["companion"]:
        CATALOG.update(host=STATE["companion"], data=companion_link.preset_catalog(STATE["companion"]),
                       at=time.strftime("%H:%M:%S"))
    return {"host": CATALOG["host"], "at": CATALOG["at"], "connections": CATALOG["data"]}


def preset_png(conn, preset, vars_json):
    key = (STATE["companion"], conn, preset, vars_json)
    if key not in PREVIEWS:
        with PREVIEW_POOL_LOCK:
            if not PREVIEW_POOL or PREVIEW_POOL[0][1].hostport != STATE["companion"]:
                for _, old in PREVIEW_POOL:
                    old.close()
                PREVIEW_POOL[:] = [(threading.Lock(), companion_link.PreviewSource(STATE["companion"])) for _ in range(4)]
            pool = list(PREVIEW_POOL)
        lock, src = pool[0]
        while True:                                   # first free socket, else wait on the first
            free = next(((l, sp) for l, sp in pool if l.acquire(blocking=False)), None)
            if free:
                lock, src = free
                break
            time.sleep(0.02)
        try:
            uri = src.get(conn, preset, json.loads(vars_json) if vars_json else None)
        finally:
            lock.release()
        if not uri:
            return None
        PREVIEWS[key] = base64.b64decode(uri.split(",", 1)[1])
    return PREVIEWS[key]


def preset_cells(layout):
    return [c for c in layout.get("cells", []) if c.get("item", {}).get("kind") == "preset"]
MODES_FILE = os.path.join(SHOWS, "modes.json")   # user data: edited built-ins + custom modes


def load_modes():
    """Built-in PVW/CUT/AUTO/HOT (with any edits) followed by custom modes, in order."""
    saved = {}
    try:
        saved = json.load(open(MODES_FILE)).get("modes", {})
    except Exception:
        pass
    out = {}
    for k, v in gen.BUILTIN_MODES.items():
        out[k] = dict(v, **saved.get(k, {}), builtin=True)
    for k, v in saved.items():
        if k not in out:
            out[k] = dict(v, builtin=False)
    return out


def save_modes(modes):
    os.makedirs(SHOWS, exist_ok=True)
    keep = {}
    for k, v in modes.items():
        v = {kk: vv for kk, vv in v.items() if kk not in ("builtin", "glyphUri")}
        if k in gen.BUILTIN_MODES and v == gen.BUILTIN_MODES[k]:
            continue                                   # unchanged built-in: nothing to store
        keep[k] = v
    json.dump({"modes": keep}, open(MODES_FILE, "w"), indent=1)


def clean_mode(d):
    take = d.get("take") if d.get("take") in ("preview", "program", "pvw_cut", "pvw_auto") else "preview"
    m = {"label": str(d.get("label") or "Mode")[:24], "tag": str(d.get("tag") or "MODE").upper()[:6],
         "color": d.get("color") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(d.get("color") or "")) else "#9aa4ad",
         "glyph": d.get("glyph") if d.get("glyph") in gen.GLYPHS else "PVW", "take": take}
    if take in ("pvw_cut", "pvw_auto"):
        m["waitMs"] = max(0, min(5000, int(d.get("waitMs") or 0)))
    if take == "pvw_auto" and d.get("style") in gen.TRANSITION_STYLES:
        m["style"] = d["style"]
        if d["style"] != "sting" and d.get("rate"):
            m["rate"] = max(1, min(250, int(d["rate"])))
    return m
ALL_SOURCES = list(gen.SOURCES) + list(gen.BUS_SOURCES)

CODE_FILES = [os.path.join(HERE, f) for f in ("show-builder.py", "companion_link.py", "donor-atem-page8.companionconfig",
                                            "donor-atem-aux.json", "donor-atem-ssrc.json")] \
    + [os.path.join(PROJECT, "tools", "atem-me-pages.py")]


def code_stamp():
    return max(os.path.getmtime(f) for f in CODE_FILES if os.path.exists(f))


STARTED_STAMP = code_stamp()   # a newer stamp means the builder was updated while running
FONTS = {"Rajdhani-Bold.ttf", "ShareTechMono-Regular.ttf", "Inter-Regular.ttf"}  # brand faces, if installed
NAMES = {}
AUXES = {}
SSBOX = {}   # "ss,box" -> current source short name, for the SuperSources this switcher has
STATE = {"companion": "192.168.10.249:8000", "names_at": None, "names_ok": False}


def read_var(name):
    url = f"http://{STATE['companion']}/api/variable/{ATEM_LABEL}/{name}/value"
    v = urllib.request.urlopen(url, timeout=2).read().decode().strip()
    return None if (not v or v == "Not found") else v


def refresh_names():
    """Read every input and AUX short name from Companion, in parallel."""
    from concurrent.futures import ThreadPoolExecutor

    def one(name):
        try:
            return name, read_var(name), True
        except Exception:
            return name, None, False

    names = [f"short_{inp}" for inp, _ in ALL_SOURCES] + [f"short_{8000 + n}" for n in range(1, MAX_AUX + 1)] \
        + [f"ssrc{ss}_box{b}_source" for ss in (1, 2) for b in range(1, 5)]
    with ThreadPoolExecutor(max_workers=16) as pool:
        res = {n: (v, ok) for n, v, ok in pool.map(one, names)}
    ok = any(r[1] for r in res.values())
    got = {str(inp): res[f"short_{inp}"][0] for inp, _ in ALL_SOURCES if res[f"short_{inp}"][0]}
    aux = {}
    for n in range(1, MAX_AUX + 1):     # AUX outputs are inputs 8001.. on the ATEM; stop at the first gap
        v = res[f"short_{8000 + n}"][0]
        if not v:
            break
        aux[str(n)] = v
    NAMES.clear()
    NAMES.update(got)
    AUXES.clear()
    AUXES.update(aux)
    SSBOX.clear()
    SSBOX.update({f"{ss},{b}": res[f"ssrc{ss}_box{b}_source"][0]
                  for ss in (1, 2) for b in range(1, 5) if res[f"ssrc{ss}_box{b}_source"][0]})
    STATE["names_ok"] = ok
    STATE["names_at"] = time.strftime("%H:%M:%S")


def hexcolor(c):
    return "#%06x" % c


def meta():
    return {
        "decks": DECKS,
        "iconGroups": json.load(open(os.path.join(ICONS_DIR, "index.json"))),
        "mes": list(gen.MES),
        "modes": {k: dict(v, glyphUri=KIT.glyph_uri(v.get("glyph", "PVW"), v.get("color", "#9aa4ad")))
                  for k, v in load_modes().items()},
        "glyphs": {g: KIT.glyph_uri(g, "#e8ecef") for g in gen.GLYPHS},
        "transitionStyles": gen.TRANSITION_STYLES,
        "sources": [{"id": i, "label": lbl} for i, lbl in gen.SOURCES],
        "busSources": [{"id": i, "label": lbl} for i, lbl in gen.BUS_SOURCES],
        "auxes": AUXES or {str(n): f"AUX {n}" for n in range(1, 13)},
        "auxLive": bool(AUXES),
        "auxColor": hexcolor(gen.AUX_COLOR), "auxOn": hexcolor(gen.AUX_ON), "auxGlyph": KIT.glyphs["AUX"],
        "titleColor": hexcolor(gen.TITLE_COLOR),
        "allColor": hexcolor(gen.ALL_COLOR), "allGlyph": KIT.glyphs["ALL"],
        "ssColor": hexcolor(gen.SS_COLOR), "ssGlyph": KIT.glyphs["SS"], "ssBoxes": SSBOX,
        "tallyColor": hexcolor(gen.TALLY_COLOR), "tallyBand": hexcolor(gen.TALLY_BAND), "tallyGlyph": gen.tally_glyph(),
        "dialFuncs": {k: {"label": v[0], "color": hexcolor(v[1]), "caption": v[2]} for k, v in gen.DIAL_FUNCS.items()},
        "maxInput": max([int(k) for k in NAMES if int(k) <= 40] or [20]),
        "liveBus": [i for i, _ in gen.BUS_SOURCES if str(i) in NAMES],
        "names": NAMES,
        "companion": STATE["companion"],
        "names_ok": STATE["names_ok"],
        "names_at": STATE["names_at"],
        "colors": {"pgm": hexcolor(gen.PGM_RED), "pvw": hexcolor(gen.PVW_GREEN)},
        "atem": ATEM_LABEL,
        "ssLooks": ss_look_shows(),
        "stale": code_stamp() > STARTED_STAMP,
    }


# ---------------------------------------------------------------- building

CAMS = {}      # camera number -> {ip, key, name}: the Cue Dials entered in the Cameras card, per build


def cam_of(item):
    n = int(item.get("cam") or 1)
    d = CAMS.get(n) or {}
    ip = str(d.get("ip") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9.\-]+(:\d+)?", ip):
        raise ValueError(f"camera {n} has no Cue Dial address - enter it in the Cameras card")
    if not str(d.get("key") or "").strip():
        raise ValueError(f"camera {n}'s Cue Dial needs its key - the 'Key ...' line at the bottom of Menu > Remote on the Dial; type it in the Cameras card")
    return n, ip, str(d["key"]).strip(), str(d.get("name") or "").strip().upper()[:12]


XAIR = {"house": 1, "shot": 2, "step": 2, "label": "xair"}      # the Audio card's fields, per build


ICONS_DIR = os.path.join(PROJECT, "button-pack", "icons")


def nav_color(item, default):
    h = str(item.get("color") or "")
    return int(h[1:], 16) if re.fullmatch(r"#[0-9a-fA-F]{6}", h) else default


def nav_icon(item, default, color):
    """A nav key's picture: their own image as is, or a pack icon in the key's colour."""
    data = str(item.get("iconData") or "")
    if re.match(r"data:image/(png|jpeg);base64,[A-Za-z0-9+/=]+$", data):
        return data
    name = os.path.basename(str(item["icon"] if "icon" in item else default))
    path = os.path.join(ICONS_DIR, name + ".png")
    if not name or not os.path.isfile(path):
        return None
    alpha = gen.Image.open(path).convert("RGBA").getchannel("A")
    im = gen.Image.new("RGBA", alpha.size, gen.rgb(color) + (255,))
    im.putalpha(alpha)
    return gen.png_uri(im)


def make_control(item):
    k = item["kind"]
    if k == "combo":
        tasks = []
        for s in item.get("steps") or []:
            if s["kind"] == "wait":
                tasks.append(max(10, min(60000, int(s.get("ms") or 500))))
                continue
            if s["kind"] in LIST_SKIP or s["kind"] == "menuicon":
                raise ValueError(f"a combo key can't hold a {s['kind']} key: it has nothing to run on a press")
            c = make_control(s)
            if c["steps"]["0"]["options"].get("runWhileHeld"):
                raise ValueError("a combo key can't hold a key that needs a press-and-hold")
            tasks.append(c)
        if not any(isinstance(t, dict) for t in tasks):
            raise ValueError("a combo key needs at least one task")
        lit = item.get("lit")
        return KIT.combo_key(str(item.get("label") or "COMBO")[:24], tasks, lit if isinstance(lit, int) else None)
    if k == "xair":
        return KIT.xair_key(item["act"], XAIR["house"], XAIR["shot"], XAIR["step"], XAIR["label"])
    if k == "camkey":
        n, ip, key, name = cam_of(item)
        return KIT.cam_key(n, ip, key, item.get("setting", "iris"), item.get("act", "show"), name)
    if k == "source":
        modes = load_modes()
        if item["mode"] not in modes:
            raise ValueError(f"mode {item['mode']} no longer exists - pick another mode for that key")
        return KIT.mode_button(modes[item["mode"]], int(item["me"]), int(item["input"]))
    if k == "transition":
        return KIT.transition_button(item["which"], int(item["me"]))
    if k == "readout":
        return KIT.readout(item["bus"], int(item["me"]))
    if k == "back":
        c = nav_color(item, 0x9AA4AD)
        return KIT.nav_page_button(int(item.get("page", 1)), str(item.get("label") or f"PAGE {item.get('page', 1)}")[:24],
                                   nav_icon(item, "home", c), c, item.get("size", "M"))
    if k == "navpage":
        if int(item.get("page") or 0) < 1:
            raise ValueError(f"the Home button for {item.get('label') or 'a page'} has no page number yet")
        c = nav_color(item, 0xE8ECEF)
        return KIT.nav_page_button(int(item["page"]), str(item.get("label") or "")[:24], nav_icon(item, "", c), c, item.get("size", "M"))
    if k == "title":
        return KIT.title_button(str(item.get("text") or "TITLE")[:24], int(item["me"]))
    if k == "aux":
        return KIT.aux_button(int(item["aux"]), int(item["input"]))
    if k == "ssbox":
        return KIT.ss_box_button(int(item["ss"]), int(item["box"]), int(item["input"]))
    if k == "ssread":
        return KIT.ss_box_readout(int(item["ss"]), int(item["box"]))
    if k == "tally":
        return KIT.tally_button(int(item["input"]), item.get("mes") or [], bool(item.get("pvw", True)),
                                item.get("ss"), item.get("ssBoxes") or ())
    if k == "all":
        return KIT.all_button(str(item.get("label") or "ALL")[:24], int(item["input"]),
                              item.get("mes") or [], item.get("auxes") or [])
    if k == "auxread":
        return KIT.aux_readout(int(item["aux"]))
    if k == "sslook":
        f = os.path.realpath(os.path.join(SS_BUILDER, item["file"]))
        if not f.startswith(os.path.realpath(SS_BUILDER)) or not os.path.isfile(f):
            raise ValueError(f"SuperSource Builder export {item['file']} is gone - re-export the show or pick another")
        c = item.get("count")
        ctl, _, _ = ss_looks_mod().look_controls(f, int(item.get("ss", 1)), c if str(c).startswith("F") else (int(c) if c else None))
        return ctl[item["look"]]
    if k == "flykey":
        fill = int(item["input"])
        luma = item.get("ktype") == "luma"
        cut = int(item.get("cut") or (fill + 1 if not luma and 3010 <= fill <= 3040 and fill % 10 == 0 else fill))   # DVE on a media player: its key output; luma keys itself
        return KIT.fly_key_button(int(item.get("me", 1)), int(item.get("key", 1)), fill, cut,
                                  item.get("from", "right"), item.get("exit", "through"), int(item.get("ms", 700)),
                                  item.get("easing", "cubic"), float(item.get("size", 100)) / 100,
                                  float(item.get("x", 0)), float(item.get("y", 0)), str(item.get("label") or "")[:24],
                                  "luma" if luma else "dve", item.get("premult", True) is not False,
                                  float(item.get("clip", 10)), float(item.get("gain", 50)))
    if k == "sscbox":
        return KIT.ssc_box_key(int(item.get("ss", 1)), int(item["box"]), ss_hi())
    if k == "sscon":
        return KIT.ssc_onoff_key(int(item.get("ss", 1)), int(item["box"]))
    if k == "sscsrc":
        return KIT.ssc_source_key(int(item.get("ss", 1)), int(item["input"]))
    if k == "sscact":
        return KIT.ssc_action_key(int(item.get("ss", 1)), item["act"], len(switcher_mes()))
    raise ValueError(f"unknown kind {k}")


def ss_hi():
    """Highest camera input the SuperSource source dial scrolls (then media players, colours, black)."""
    return max([int(k) for k in NAMES if int(k) <= 40] or [20])


def ss_extra():
    ids = [i for i in (3010, 3020, 3030, 3040, 2001, 2002, 1000, 0)]
    live = [i for i in ids if str(i) in NAMES]
    return live or [3010, 3020, 0]


def switcher_mes():
    mes = [m for m in (1, 2, 3, 4) if str(10000 + m * 10) in NAMES]
    return mes or [1, 2]


def bus_extra(it):
    """M/E outputs and clean feeds an AUX dial scrolls into after its inputs:
    the ones saved on the item, else the ones this switcher reports."""
    if not it.get("bus", True):
        return []
    if it.get("extra") is not None:
        return [int(x) for x in it["extra"]]
    return [i for i, _ in gen.BUS_SOURCES if str(i) in NAMES]


def recolor(ctl, item):
    """Rob's colour pick for a key: the border, the text that wore the old border colour,
    and a source key's mode glyph. Fill stays black (feedback fills are untouched)."""
    hexc = str(item.get("color") or "")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", hexc):
        return ctl
    new = int(hexc[1:], 16)
    box = next((l for l in ctl["style"]["layers"] if l["id"] == "box0"), None)
    old = box and box.get("borderColor", {}).get("value")
    for l in ctl["style"]["layers"]:
        if l["id"] == "box0":
            l["borderColor"] = gen.wrap(new)
        elif l["type"] == "text" and l["id"] != "text0" and l.get("color", {}).get("value") == old:
            l["color"] = gen.wrap(new)
        elif l["id"] == "image0" and item.get("kind") == "source":
            m = load_modes().get(item.get("mode"), {})
            if l.get("enabled", {}).get("value", True) is not False and l.get("base64Image", {}).get("value"):
                l["base64Image"] = gen.wrap(KIT.glyph_uri(m.get("glyph", "PVW"), hexc))
    return ctl


LIST_SKIP = {"preset", "readout", "auxread", "ssread", "title", "tally", "dial", "navpage"}   # nothing to run on a press


def build_page(layout):
    controls = {}
    xa = layout.get("xair") or {}
    XAIR.update(house=max(1, min(16, int(xa.get("house") or 1))), shot=max(1, min(16, int(xa.get("shot") or 2))),
                step=max(1, min(10, int(xa.get("step") or 2))), label=str(layout.get("xairLabel") or "xair"))
    if XAIR["house"] == XAIR["shot"]:
        raise ValueError("the Audio card's house and shotgun channels are the same")
    CAMS.clear()
    CAMS.update({int(c["n"]): c for c in layout.get("cams") or [] if str(c.get("n", "")).isdigit()})
    for cell in layout["cells"]:
        it = cell["item"]
        if it["kind"] == "preset":
            continue                      # placed live by Companion after a Send (controls.importPreset)
        if it["kind"] == "dial":
            c = int(cell["c"])
            if c not in gen.DIAL_COLS:
                raise ValueError(f"no encoder at column {c}")
            if it["func"] in ("sscsrc", "sscbox", "sscx", "sscy", "sscsize"):
                strip, knob = KIT.ssc_dial(int(it.get("ss", 1)), it["func"], ss_hi(), ss_extra())
                controls.setdefault("4", {})[str(c)] = strip
                controls.setdefault("5", {})[str(c)] = knob
                continue
            if it["func"] == "xairlevel":
                strip, knob = KIT.xair_dial(XAIR["shot"], 1, XAIR["label"])
                controls.setdefault("4", {})[str(c)] = strip
                controls.setdefault("5", {})[str(c)] = knob
                continue
            if it["func"] == "cam":
                n, ip, key, name = cam_of(it)
                strip, knob = KIT.cam_dial(n, ip, key, it.get("setting", "iris"), name)
                controls.setdefault("4", {})[str(c)] = strip
                controls.setdefault("5", {})[str(c)] = knob
                continue
            if it["func"] == "tbar":
                strip, knob = KIT.tbar_dial(int(it["target"]), int(it.get("step") or 5))
                controls.setdefault("4", {})[str(c)] = strip
                controls.setdefault("5", {})[str(c)] = knob
                continue
            if it["func"] == "list":
                entries = it.get("items") or []
                if not 2 <= len(entries) <= 40:
                    raise ValueError("a list dial holds 2 to 40 keys")
                if any(e["item"]["kind"] in LIST_SKIP for e in entries):
                    raise ValueError("a list dial can't hold presets, readouts, titles or tally keys")
                strip, knob = KIT.list_dial(f"l{c}", str(it.get("title") or "LIST")[:24].upper(),
                                            [(make_control(e["item"]), str(e.get("label") or "?")[:24],
                                              str(e.get("sub") or "")[:32]) for e in entries])
                controls.setdefault("4", {})[str(c)] = strip
                controls.setdefault("5", {})[str(c)] = knob
                continue
            lo, hi = sorted((int(it.get("lo", 1)), int(it.get("hi", 20))))
            if it["func"] == "auxpair":
                nxt = [d for d in gen.DIAL_COLS if d > c]
                if not nxt:
                    raise ValueError("an AUX pair needs a second dial to the right")
                c2 = nxt[0]
                sa, ka, sb, kb = KIT.aux_pair(f"p{c}", int(it.get("auxHi") or len(AUXES) or 12), lo, hi, bus_extra(it))
                controls.setdefault("4", {}).update({str(c): sa, str(c2): sb})
                controls.setdefault("5", {}).update({str(c): ka, str(c2): kb})
                continue
            strip, knob = KIT.dial(it["func"], int(it["target"]), lo, hi, bus_extra(it))
            controls.setdefault("4", {})[str(c)] = strip
            controls.setdefault("5", {})[str(c)] = knob
            continue
        r, c = str(int(cell["r"])), str(int(cell["c"]))
        if it["kind"] == "menuicon":                 # copy onto the Menu: jumps to the page this layout lands on
            icon = os.path.join(PROJECT, "button-pack", os.path.basename(str(it.get("icon") or "supersource")) + ".png")
            uri = "data:image/png;base64," + base64.b64encode(open(icon, "rb").read()).decode()
            target = int(layout.get("menuTarget") or layout.get("targetPage") or layout.get("pageNo") or 1)
            controls.setdefault(r, {})[c] = KIT.nav_button(target if target > 0 else 1, uri)
            continue
        controls.setdefault(r, {})[c] = recolor(make_control(it), it)
    name = layout.get("name") or "ATEM SHOW"
    used = json.dumps(controls)
    extra = {cid: copy.deepcopy(inst) for cid, inst in ((KIT.DIALS_CONN, KIT.DIALS_INSTANCE), (KIT.XAIR_CONN, KIT.XAIR_INSTANCE))
             if cid in used}
    return {
        "version": EXAMPLE["version"], "type": "page", "companionBuild": EXAMPLE["companionBuild"],
        "page": {"id": gen.nid(), "name": name, "controls": controls,
                 "gridSize": EXAMPLE["page"]["gridSize"]},
        "oldPageNumber": int(layout.get("pageNo") or 1),
        "instances": dict(copy.deepcopy(EXAMPLE["instances"]), **extra),
        "connectionCollections": [], "imageLibrary": [], "imageLibraryCollections": [],
    }


def slug(s):
    return re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-") or "show"


def write_gz(path, obj):
    open(path, "wb").write(gzip.compress(json.dumps(obj).encode()))
    json.loads(gzip.decompress(open(path, "rb").read()))  # read-back check
    return path


def full_exports():
    out = []
    for p in glob.glob(os.path.join(DOWNLOADS, "*.companionconfig")):
        try:
            head = json.loads(gzip.decompress(open(p, "rb").read()))
        except Exception:
            continue
        if head.get("type") != "full":
            continue
        pages = {n: pg.get("name", "") for n, pg in head.get("pages", {}).items()}
        out.append({"path": p, "file": os.path.basename(p), "mtime": os.path.getmtime(p),
                    "pages": pages, "hasAtem": any(k in head.get("instances", {}) for k in EXAMPLE["instances"])})
    return sorted(out, key=lambda x: -x["mtime"])


def export(layout):
    """Page file (one page) or, with output "merge", every builder page in layout["batch"]
    (or just this layout) placed into one copy of the chosen full export."""
    name = slug(layout.get("name") or "ATEM SHOW")
    if layout.get("output") == "merge":
        src = layout["mergeSrc"]
        full = json.loads(gzip.decompress(open(src, "rb").read()))
        if full.get("type") != "full":
            raise ValueError("that file is not a full config export")
        for cid in EXAMPLE["instances"]:
            if cid not in full.get("instances", {}):
                raise ValueError("the ATEM connection in that export does not match the kit")
        bodies = layout.get("batch") or [layout]
        nums = [str(int(b["pageNo"])) for b in bodies]
        if len(set(nums)) != len(nums):
            raise ValueError("two builder pages are aimed at the same page number")
        for b, n in zip(bodies, nums):
            page = build_page(dict(layout, **b))
            ctl = page["page"]["controls"]
            for stand_in in (KIT.DIALS_CONN, KIT.XAIR_CONN):   # that export's own connection for these keys
                if stand_in not in page["instances"]:
                    continue
                inst = page["instances"][stand_in]
                same = [cid for cid, c in full["instances"].items() if c and c.get("moduleId") == inst["moduleId"]]
                own = [cid for cid in same if full["instances"][cid].get("label") == inst["label"]] or same
                if own:
                    ctl = json.loads(json.dumps(ctl).replace(stand_in, own[0]))
                    if stand_in == KIT.XAIR_CONN and own[0] != stand_in:
                        ctl = json.loads(json.dumps(ctl).replace("$(xair:", "$(" + full["instances"][own[0]].get("label", "xair") + ":"))
                else:
                    full["instances"][stand_in] = inst
            slot = full["pages"].get(n)
            full["pages"][n] = {"id": slot["id"] if slot else gen.nid(), "name": page["page"]["name"],
                                "controls": ctl, "gridSize": page["page"]["gridSize"]}
        stem = os.path.splitext(os.path.basename(src))[0]
        tag = f"{name}-p{nums[0]}" if len(nums) == 1 else f"{len(nums)}pages-p{'-'.join(nums)}"
        return write_gz(os.path.join(DOWNLOADS, f"{stem}_SHOW-{tag}.companionconfig"), full)
    return write_gz(os.path.join(DOWNLOADS, f"show-{name}.companionconfig"), build_page(layout))


# ---------------------------------------------------------------- http

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        try:
            if self.path in ("/", "/index.html"):
                return self.send(200, open(os.path.join(HERE, "index.html"), "rb").read(), "text/html; charset=utf-8")
            if self.path.startswith("/fonts/"):
                f = os.path.basename(self.path)
                if f in FONTS:
                    for d in (os.path.join(PROJECT, "fonts"), os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"):
                        if os.path.isfile(os.path.join(d, f)):
                            return self.send(200, open(os.path.join(d, f), "rb").read(), "font/ttf")
                return self.send(404, {"error": "font not installed"})
            if self.path.startswith("/icons/"):
                f = os.path.join(ICONS_DIR, os.path.basename(self.path))
                if f.endswith(".png") and os.path.isfile(f):
                    return self.send(200, open(f, "rb").read(), "image/png")
                return self.send(404, {"error": "no such icon"})
            if self.path == "/app-icon.png":
                return self.send(200, open(os.path.join(HERE, "app-icon.png"), "rb").read(), "image/png")
            if self.path == "/api/meta":
                return self.send(200, meta())
            if self.path.startswith("/api/connections"):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                return self.send(200, catalog(refresh="refresh" in q))
            if self.path.startswith("/api/preset/preview"):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                png = preset_png(q["c"][0], q["p"][0], (q.get("v") or [""])[0])
                if png is None:
                    return self.send(404, {"error": "no preview"})
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(png)))
                self.send_header("Cache-Control", "max-age=600")
                self.end_headers()
                self.wfile.write(png)
                return
            if self.path == "/api/companion/pages":
                return self.send(200, {"host": STATE["companion"], "pages": companion_link.pages(STATE["companion"])})
            if self.path == "/api/exports":
                return self.send(200, full_exports())
            if self.path == "/api/shows":
                os.makedirs(SHOWS, exist_ok=True)
                items = [{"file": os.path.basename(p), "mtime": os.path.getmtime(p)}
                         for p in glob.glob(os.path.join(SHOWS, "*.json")) if p != MODES_FILE]
                return self.send(200, sorted(items, key=lambda x: -x["mtime"]))
            if self.path.startswith("/api/shows/"):
                f = os.path.basename(self.path.split("/api/shows/", 1)[1])
                return self.send(200, json.load(open(os.path.join(SHOWS, f))))
            self.send(404, {"error": "not found"})
        except Exception as e:
            self.send(500, {"error": str(e)})

    def do_POST(self):
        try:
            b = self.body()
            if self.path == "/api/refresh":
                if b.get("companion"):
                    STATE["companion"] = b["companion"].strip()
                    if DATA:
                        open(os.path.join(DATA, "companion.txt"), "w").write(STATE["companion"])
                refresh_names()
                return self.send(200, meta())
            if self.path == "/api/send":
                b["xairLabel"] = next((c["label"] for c in companion_link.connections(STATE["companion"]).values()
                                       if c.get("moduleId") == "behringer-xair"), "xair")   # its variables go by this label
                if int(b.get("targetPage", -1)) == -1:      # "new page at the end": the menu-icon key needs the real number
                    b["menuTarget"] = len(companion_link.pages(STATE["companion"])) + 1
                page = build_page(b)
                data = gzip.compress(json.dumps(page).encode())
                target = int(b.get("targetPage", -1))
                print(time.strftime("%H:%M:%S"), "send", repr(page["page"]["name"]), "-> page", target,
                      "on", STATE["companion"], flush=True)
                mapping, reply = companion_link.send_page(STATE["companion"], data, target,
                                                          name=f"{slug(page['page']['name'])}.companionconfig")
                live = companion_link.pages(STATE["companion"])
                landed = target if target > 0 else len(live)
                placements = [dict(c["item"], row=int(c["r"]), column=int(c["c"]),
                                   connectionId=c["item"]["conn"], presetId=c["item"]["presetId"])
                              for c in preset_cells(b)]
                errors = companion_link.import_presets(STATE["companion"], landed, placements)
                live = companion_link.pages(STATE["companion"])
                got = next((p for p in live if p["n"] == landed), None)
                return self.send(200, {"host": STATE["companion"], "page": landed, "now": got, "mapping": mapping,
                                       "presets": len(placements), "presetErrors": errors})
            if self.path == "/api/modes/save":
                modes = load_modes()
                key = b.get("key")
                if not key:                                   # new custom mode: key from its tag
                    base = re.sub(r"[^A-Z0-9]", "", str(b.get("tag") or "MODE").upper()) or "MODE"
                    key, n = base, 2
                    while key in modes:
                        key, n = f"{base}{n}", n + 1
                modes[key] = dict(clean_mode(b), builtin=key in gen.BUILTIN_MODES)
                save_modes(modes)
                return self.send(200, {"key": key, "meta": meta()})
            if self.path == "/api/modes/delete":
                modes = load_modes()
                key = b.get("key")
                if key in gen.BUILTIN_MODES:
                    modes[key] = dict(gen.BUILTIN_MODES[key])  # built-ins reset instead of delete
                else:
                    modes.pop(key, None)
                save_modes(modes)
                return self.send(200, {"meta": meta()})
            if self.path == "/api/camtest":                  # a Cue Dial: reachable, its camera, and the key (read-only checks)
                ip = str(b.get("ip") or "").strip()
                if not re.fullmatch(r"[A-Za-z0-9.\-]+(:\d+)?", ip):
                    return self.send(200, {"ok": False, "msg": "enter the Dial's address"})
                try:
                    st = json.loads(urllib.request.urlopen(f"http://{ip}/s", timeout=3).read())
                except Exception:
                    return self.send(200, {"ok": False, "msg": f"no Cue Dial at {ip}"})
                d = st.get("dial") or {}
                vals = {x.get("n"): x.get("v") for x in d.get("p") or []}
                try:
                    urllib.request.urlopen(f"http://{ip}/wifi?k={urllib.parse.quote(str(b.get('key') or ''))}", timeout=3)
                    key_ok = True
                except urllib.error.HTTPError as e:
                    key_ok = e.code != 401
                except Exception:
                    key_ok = None
                return self.send(200, {"ok": True, "name": st.get("name"), "cam": d.get("cam"), "linked": bool(d.get("cam")),
                                       "iris": vals.get("IRIS"), "gain": vals.get("GAIN"), "keyOk": key_ok})
            if self.path == "/api/export":
                path = export(b)
                return self.send(200, {"path": path, "file": os.path.basename(path), "skippedPresets": len(preset_cells(b))})
            if self.path == "/api/save":
                os.makedirs(SHOWS, exist_ok=True)
                path = os.path.join(SHOWS, slug(b.get("name") or "show") + ".json")
                json.dump(b, open(path, "w"), indent=1)
                return self.send(200, {"file": os.path.basename(path)})
            if self.path == "/api/reveal":
                p = b.get("path", "")
                if os.path.isfile(p) and os.path.dirname(p) in (DOWNLOADS, SHOWS):
                    subprocess.run(["open", "-R", p])
                return self.send(200, {"ok": True})
            if self.path == "/api/restart":
                self.send(200, {"ok": True})

                def again():
                    time.sleep(0.3)
                    self.server.server_close()
                    os.execv(sys.executable, [sys.executable] + sys.argv)
                threading.Thread(target=again, daemon=True).start()
                return
            if self.path == "/api/quit":
                self.send(200, {"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            self.send(404, {"error": "not found"})
        except Exception as e:
            if self.path in ("/api/send", "/api/export"):         # what failed, for the log
                import traceback
                print(time.strftime("%H:%M:%S"), self.path, "FAILED:", e, flush=True)
                traceback.print_exc()
            self.send(400, {"error": str(e)})


def main():
    if DATA:                                # the app has no address of ours built in: this Mac's, until they enter another
        os.makedirs(SHOWS, exist_ok=True)
        saved = os.path.join(DATA, "companion.txt")
        STATE["companion"] = open(saved).read().strip() if os.path.isfile(saved) else "127.0.0.1:8000"
        def watch_parent():                 # never outlive the app window
            while os.getppid() != 1:
                time.sleep(2)
            os._exit(0)
        threading.Thread(target=watch_parent, daemon=True).start()
    ap = argparse.ArgumentParser()
    ap.add_argument("--companion", default=STATE["companion"])
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    STATE["companion"] = a.companion
    threading.Thread(target=refresh_names, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    url = f"http://127.0.0.1:{a.port}/"
    print("Downstage Show Builder:", url, flush=True)
    if not a.no_browser:
        webbrowser.open(url)
    srv.serve_forever()


if __name__ == "__main__":
    main()
