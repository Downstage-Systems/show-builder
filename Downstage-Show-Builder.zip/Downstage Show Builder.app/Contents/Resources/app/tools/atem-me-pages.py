#!/usr/bin/env python3
"""Generate the ATEM M/E button library pages from Rob's example page.

Usage:
    python3 atem-me-pages.py <example-page.companionconfig> <out-dir> [names.json]

The example page (exported from the One, page "ATEM ME1") supplies every
action, feedback and local-variable object - nothing is hand-built. Each
button carries local variables `me` and `input`; retargeting a pasted button
is just editing those two values.

Output: one page per M/E per mode (PVW, CUT, AUTO, HOT) = 16 pages, plus an
ATEM HOME page with a button per kit page. Page numbers are Rob's to assign:
the HOME buttons' set_page targets are placeholders (page 1) to be set after
import. Mode/M-E icons are also written to <out-dir>/icons/.
names.json (optional) maps input id -> short name, used only for previews.
"""
import base64, copy, gzip, io, json, os, secrets, sys

from PIL import Image, ImageDraw, ImageFont

MES = (1, 2, 3, 4)
SOURCES = (
    [(n, f"IN {n}") for n in range(1, 31)]
    + [(3010, "MP1"), (3020, "MP2"), (3030, "MP3"), (3040, "MP4")]
    + [(6000, "SS1"), (6001, "SS2")]
    + [(0, "BLK"), (1000, "BARS"), (2001, "COL1"), (2002, "COL2")]
)

BUS_SOURCES = (   # ATEM bus outputs usable as sources (AUX, cascades): not on the kit pages
    [(10000 + 10 * m + k, f"M/E{m} {'PVW' if k else 'PGM'}") for m in range(1, 5) for k in (0, 1)]
    + [(7000 + n, f"CLN {n}") for n in range(1, 5)]
)

DARK = 0x000000   # idle (no-feedback) button background: pure black
GREY = 0x9AA3AD
MODES = {
    # key: (page label, tag, border color)
    "PVW":  ("Preview",   "PVW",  0x2E90D9),
    "CUT":  ("Cut",       "CUT",  0xF5A524),
    "AUTO": ("Auto",      "AUTO", 0x8E6FE6),
    "HOT":  ("Hot Punch", "HOT",  0xE040FB),
}
PGM_RED, PVW_GREEN = 0xE5484D, 0x2FD97B
PLACEHOLDER_PAGE = 1  # set_page target on HOME buttons until Rob assigns pages

# Switching-mode recipes (Show Builder). take: preview | program | pvw_cut | pvw_auto.
# style/rate (pvw_auto only): set on the key's M/E right after the preview, before the wait.
BUILTIN_MODES = {
    "PVW":  {"label": "Preview",   "tag": "PVW",  "color": "#2e90d9", "glyph": "PVW",  "take": "preview"},
    "CUT":  {"label": "Cut",       "tag": "CUT",  "color": "#f5a524", "glyph": "CUT",  "take": "program"},
    "AUTO": {"label": "Auto",      "tag": "AUTO", "color": "#8e6fe6", "glyph": "AUTO", "take": "pvw_auto", "waitMs": 500},
    "HOT":  {"label": "Hot Punch", "tag": "HOT",  "color": "#e040fb", "glyph": "HOT",  "take": "pvw_cut", "waitMs": 100},
}
GLYPHS = ["PVW", "CUT", "AUTO", "HOT", "DIP", "WIPE", "DVE", "ALL"]
TRANSITION_STYLES = ["mix", "dip", "wipe", "dve", "sting"]

AUX_COLOR = 0xE93D82       # AUX key border: the Show Builder's AUX pink (was neutral 0xE8ECEF)
AUX_ON = 0xE93D82          # AUX key fill while its source is routed (pink; was Cue Violet 0x8E6FE6)
TITLE_COLOR = 0x9AA4AD     # M/E title border
ALL_COLOR = 0xF5A524       # ALL key border (matches the button-pack ALL icon)
TALLY_COLOR = 0x5E6773     # tally key border (neutral: the fill carries the tally)
TALLY_BAND = 0x4A1519      # tally key top band: dark red, readable on black, red and green
SS_COLOR = 0x2BB5B8        # SuperSource box key border and "in the box" fill (teal: unused elsewhere)
DIAL_COLS = (0, 2, 3, 5, 6, 8)   # + XL encoders (row 5) and their strip segments (row 4)
DIAL_FUNCS = {             # func: (label, border colour, press caption)
    "aux": ("AUX", AUX_COLOR, "PRESS = SEND"),
    "pvw": ("PVW", 0x2E90D9, "PRESS = PREVIEW"),
    "cut": ("CUT", 0xF5A524, "PRESS = TAKE"),
    "auxpair": ("AUX PAIR", AUX_COLOR, "PRESS = SEND"),   # two dials: AUX select + source
    "list": ("LIST", 0x8E6FE6, "PRESS = RUN"),            # keys folded onto a dial (Show Builder)
    "tbar": ("T-BAR", 0xFF7A3D, "PRESS = AUTO"),         # dial as a T-bar: the strip arrow shows which way to turn
    "sscsrc": ("SS SOURCE", SS_COLOR, "PRESS = PUT IN"),   # SuperSource controller dials
    "sscbox": ("SS BOX", SS_COLOR, "PRESS = ON/OFF"),
    "sscx": ("SS X", 0xFF7A3D, "PRESS = CENTRE"),
    "sscy": ("SS Y", 0xFF7A3D, "PRESS = CENTRE"),
    "sscsize": ("SS SIZE", 0xFF7A3D, "PRESS = 50%"),
    "xairlevel": ("AMBIENT", 0x38C7E8, "PRESS = MUTE"),    # XR18 ambient fader (Audio card)
    "cam": ("CAMERA", 0xF5A524, "PRESS = FINE"),           # Cue Dial iris / gain (colour per setting)
}


def aux_name_expr(aux_expr):
    """Live AUX short name (input 8000 + n) via parseVariables."""
    return f'parseVariables(concat("$", "(ATEM:short_", 8000 + ({aux_expr}), ")"), concat("AUX ", {aux_expr}))'

def _label_expr(v):
    """Bottom label for an input number held in expression `v`."""
    cases = [(f"{v} == {i}", f'"{lbl}"') for i, lbl in BUS_SOURCES]
    cases += [
        (f"{v} >= 6000", f'concat("SS", {v} - 5999)'),
        (f"{v} >= 3010", f'concat("MP", ({v} - 3000) / 10)'),
        (f"{v} == 0", '"BLK"'),
        (f"{v} == 1000", '"BARS"'),
        (f"{v} >= 2001", f'concat("COL", {v} - 2000)'),
    ]
    out = f'concat("IN ", {v})'
    for cond, val in reversed(cases):
        out = f"({cond} ? {val} : {out})"
    return out


INPUT_LABEL_EXPR = _label_expr("$(local:input)")


def nid():
    return secrets.token_urlsafe(16)[:21]


# Every uskDveProperties option, at the module's defaults. Companion 5 validates all of an action's
# options, even ones `properties` leaves unused, and drops the action ("borderBevel: Value is not in the
# list of choices", "rate: A value must be provided") when any is missing - so merge these under your values.
DVE_DEFAULTS = {"transitionRate": 0, "transitionEasing": "linear", "transitionCurve": "ease-in",
                "positionX": 0, "positionY": 0, "sizeX": 0.5, "sizeY": 0.5, "rotation": 0,
                "maskEnabled": True, "maskTop": 0, "maskBottom": 0, "maskLeft": 0, "maskRight": 0,
                "shadowEnabled": False, "lightSourceDirection": 36, "lightSourceAltitude": 25,
                "borderEnabled": True, "borderHue": 0, "borderSaturation": 0, "borderLuma": 0, "borderBevel": 0,
                "borderOuterWidth": 0, "borderInnerWidth": 0.2, "borderOuterSoftness": 0, "borderInnerSoftness": 0,
                "borderOpacity": 100, "borderBevelPosition": 0, "borderBevelSoftness": 0, "rate": 25}


def wrap(v, expr=False):
    return {"value": v, "isExpression": expr}


def rgb(c):
    return (c >> 16 & 255, c >> 8 & 255, c & 255)


def png_uri(im):
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def font(sz):
    for p in ("/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/HelveticaNeue.ttc"):
        try:
            return ImageFont.truetype(p, sz, index=1)
        except Exception:
            pass
    return ImageFont.load_default()


# ---------------------------------------------------------------- glyphs

def draw_glyph(d, mode, box, color, w):
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    sx, sy = (x1 - x0), (y1 - y0)
    if mode == "PVW":  # eye
        d.ellipse([x0, cy - sy * 0.30, x1, cy + sy * 0.30], outline=color, width=w)
        r = sy * 0.16
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    elif mode == "CUT":  # scissors
        r = sx * 0.16
        for oy in (-1, 1):
            ex, ey = x0 + r + 2, cy + oy * sy * 0.24
            d.ellipse([ex - r, ey - r, ex + r, ey + r], outline=color, width=w)
        d.line([x0 + 2 * r, cy - sy * 0.16, x1, cy + sy * 0.30], fill=color, width=w)
        d.line([x0 + 2 * r, cy + sy * 0.16, x1, cy - sy * 0.30], fill=color, width=w)
    elif mode == "AUTO":  # dissolve: square with diagonal half fill
        d.polygon([(x1, y0), (x1, y1), (x0, y1)], fill=color)
        d.rectangle([x0, y0, x1, y1], outline=color, width=w)
    elif mode == "AUX":  # output: screen with an arrow into it
        d.rounded_rectangle([x0 + sx * 0.38, y0 + sy * 0.12, x1, y1 - sy * 0.20], radius=int(sx * 0.08), outline=color, width=w)
        d.line([x0, cy - sy * 0.04, x0 + sx * 0.62, cy - sy * 0.04], fill=color, width=w)
        d.polygon([(x0 + sx * 0.70, cy - sy * 0.04), (x0 + sx * 0.52, cy - sy * 0.20), (x0 + sx * 0.52, cy + sy * 0.12)], fill=color)
    elif mode == "DIP":  # a V: fade down to a colour and back up
        d.line([x0, y0 + sy * 0.15, cx, y1 - sy * 0.12, x1, y0 + sy * 0.15], fill=color, width=w, joint="curve")
        d.line([x0, y1, x1, y1], fill=color, width=max(2, w // 2))
    elif mode == "WIPE":  # frame with a hard vertical edge, left half filled
        d.rectangle([x0, y0 + sy * 0.12, cx, y1 - sy * 0.12], fill=color)
        d.rectangle([x0, y0 + sy * 0.12, x1, y1 - sy * 0.12], outline=color, width=w)
    elif mode == "DVE":  # picture in picture
        d.rectangle([x0, y0 + sy * 0.1, x1, y1 - sy * 0.1], outline=color, width=w)
        d.rectangle([cx, cy - sy * 0.05, x1 - sx * 0.12, y1 - sy * 0.22], fill=color)
    elif mode == "SS":  # four boxes, one filled
        g = sx / 2
        for r in range(2):
            for c in range(2):
                bx, by = x0 + c * g + g * 0.1, y0 + r * g + g * 0.1
                box = [bx, by, bx + g * 0.8, by + g * 0.8]
                if (r, c) == (0, 1):
                    d.rounded_rectangle(box, radius=int(g * 0.16), fill=color)
                else:
                    d.rounded_rectangle(box, radius=int(g * 0.16), outline=color, width=max(2, w // 2))
    elif mode == "ALL":  # 3x3 grid of lit outputs
        g = sx / 3
        for r in range(3):
            for c in range(3):
                bx, by = x0 + c * g + g * 0.14, y0 + r * g + g * 0.14
                d.rounded_rectangle([bx, by, bx + g * 0.72, by + g * 0.72], radius=int(g * 0.18), fill=color)
    elif mode == "HOT":  # lightning bolt
        pts = [(0.58, 0.00), (0.18, 0.56), (0.46, 0.56), (0.36, 1.00), (0.82, 0.40), (0.54, 0.40), (0.66, 0.00)]
        d.polygon([(x0 + px * sx, y0 + py * sy) for px, py in pts], fill=color)


def corner_glyph(mode):
    color = {"AUX": AUX_COLOR, "ALL": ALL_COLOR, "SS": SS_COLOR}.get(mode) or MODES[mode][2]
    im = Image.new("RGBA", (72, 72), (0, 0, 0, 0))
    draw_glyph(ImageDraw.Draw(im), mode, (6, 6, 66, 66), rgb(color) + (255,), 8)
    return png_uri(im)


def tally_glyph():
    """Camera with a lit tally lamp on top - white body, red lamp."""
    im = Image.new("RGBA", (72, 72), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    white, red = (232, 236, 239, 255), rgb(PGM_RED) + (255,)
    d.rounded_rectangle([6, 28, 48, 62], radius=7, outline=white, width=6)
    d.polygon([(48, 38), (66, 28), (66, 62), (48, 52)], fill=white)
    d.ellipse([18, 6, 36, 24], fill=red)
    return png_uri(im)


def strip_art(func, color=None):
    """288x144 strip segment (the verified Mitti + XL recipe): border and rotate
    arrows in the function colour (or `color`); live text layers sit on top."""
    color = DIAL_FUNCS[func][1] if color is None else color
    W, H = 288, 144
    c = rgb(color) + (255,)
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((4, 4, W - 5, H - 5), radius=18, outline=c, width=4)
    for cx, ccw in ((30, True), (W - 30, False)):
        cy = 26
        d.arc((cx - 11, cy - 11, cx + 11, cy + 11), start=200 if ccw else 20, end=40 if ccw else 220, fill=c, width=3)
        tip = (cx + 11, cy - 4) if ccw else (cx - 11, cy + 4)
        pts = [tip, (tip[0] - 5, tip[1] - 5), (tip[0] - 6, tip[1] + 3)] if ccw else \
              [tip, (tip[0] + 5, tip[1] + 5), (tip[0] + 6, tip[1] - 3)]
        d.polygon(pts, fill=c)
    return png_uri(im)     # text rides in layers: head / value / foot stacked inside the frame


def tbar_art(left, color=None):
    """288x144 T-bar strip: the dial frame plus a big arrow pointing the way to turn.
    The arrow sits faint behind the text layers (head / percent / foot)."""
    color = DIAL_FUNCS["tbar"][1] if color is None else color
    W, H = 288, 144
    c = rgb(color)
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((4, 4, W - 5, H - 5), radius=18, outline=c + (255,), width=4)
    y0, y1, ym = 44, 100, 72                         # arrow band, between the head and foot text
    shaft = [(40, ym - 9), (W - 92, ym - 9), (W - 92, ym + 9), (40, ym + 9)]
    head = [(W - 96, y0), (W - 36, ym), (W - 96, y1)]
    if left:
        shaft = [(W - x, y) for x, y in shaft]
        head = [(W - x, y) for x, y in head]
    d.polygon(shaft, fill=c + (110,))
    d.polygon(head, fill=c + (150,))
    return png_uri(im)


def title_tile(me, mode):
    label, _, color = MODES[mode]
    im = Image.new("RGBA", (144, 144), rgb(DARK) + (255,))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([3, 3, 140, 140], radius=18, outline=rgb(color), width=6)
    draw_glyph(d, mode, (44, 18, 100, 70), rgb(color), 6)
    d.text((72, 92), f"M/E {me}", anchor="mm", font=font(28), fill=(255, 255, 255))
    d.text((72, 120), label.upper(), anchor="mm", font=font(17), fill=rgb(color))
    return png_uri(im)


# ---------------------------------------------------------------- builders

class Kit:
    def __init__(self, example, aux_donor=None, ss_donor=None):
        self.ex = example
        self.aux_donor = aux_donor
        self.ss_donor = ss_donor
        c = example["page"]["controls"]
        self.nav = c["0"]["0"]
        self.cut_t = c["0"]["7"]
        self.auto_t = c["0"]["8"]
        self.pvw = c["1"]["0"]
        self.cut = c["2"]["0"]
        self.auto = c["3"]["0"]
        self.conn = next(iter(example["instances"]))
        self.glyphs = {m: corner_glyph(m) for m in list(MODES) + ["AUX", "ALL", "SS"]}
        acts = self.auto["steps"]["0"]["action_sets"]["down"]
        self.wait = next(a for a in acts if a["definitionId"] == "wait")
        self.nav = self.black_ground(self.nav)

    @staticmethod
    def black_ground(ctl):
        """Repaint an image layer's #0B0D10 ground to the idle black."""
        ctl = copy.deepcopy(ctl)
        for l in ctl["style"]["layers"]:
            v = l.get("base64Image", {}).get("value") if l["type"] == "image" else None
            if isinstance(v, str) and v.startswith("data:image"):
                im = Image.open(io.BytesIO(base64.b64decode(v.split(",", 1)[1]))).convert("RGBA")
                px = im.load()
                for y in range(im.size[1]):
                    for x in range(im.size[0]):
                        if px[x, y][:3] == (11, 13, 16):
                            px[x, y] = rgb(DARK) + (px[x, y][3],)
                l["base64Image"] = wrap(png_uri(im))
        return ctl

    @staticmethod
    def fresh(obj):
        """Deep copy with new ids for actions, feedbacks, overrides, local vars."""
        o = copy.deepcopy(obj)

        def walk(x):
            if isinstance(x, dict):
                if x.get("type") in ("action", "feedback") and "id" in x:
                    x["id"] = nid()
                if "overrideId" in x:
                    x["overrideId"] = nid()
                for v in x.values():
                    walk(v)
            elif isinstance(x, list):
                for v in x:
                    walk(v)
        walk(o)
        return o

    @staticmethod
    def set_locals(ctl, me, inp=None):
        for lv in ctl.get("localVariables", []):
            if lv.get("variableName") == "me":
                lv["options"]["startup_value"] = wrap(me)
            elif lv.get("variableName") == "input" and inp is not None:
                lv["options"]["startup_value"] = wrap(inp)

    @staticmethod
    def localize(obj):
        """Point every mixeffect/input option at the button's local variables."""
        for k, var in (("mixeffect", "$(local:me)"), ("input", "$(local:input)"), ("aux", "$(local:aux)"),
                       ("source", "$(local:input)"), ("ssrcId", "$(local:ss)"), ("boxIndex", "$(local:box)")):
            if k in obj.get("options", {}):
                obj["options"][k] = wrap(var, True)
        return obj

    def text_layer(self, text, expr, y, size, color, x=0):
        base = next(l for l in self.pvw["style"]["layers"] if l["id"] == "text0")
        l = copy.deepcopy(base)
        l["id"] = nid()
        l["name"] = "Text"
        l["text"] = wrap(text, expr)
        l["x"], l["y"] = wrap(x), wrap(y)
        l["fontsize"] = wrap(size)
        l["color"] = wrap(color)
        return l

    def style_source(self, ctl, mode):
        _, tag, color = MODES[mode]
        layers = ctl["style"]["layers"]
        for l in layers:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(color)
                l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["base64Image"] = wrap(self.glyphs[mode])
                l["x"], l["y"] = wrap(7), wrap(7)
                l["width"], l["height"] = wrap(22), wrap(22)
                l["halign"], l["valign"] = wrap("left"), wrap("top")
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["fontsize"] = wrap(30)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2)
        layers.append(self.text_layer(f'concat("M", $(local:me), " {tag}")', True, -37, 13, color, x=9))
        layers.append(self.text_layer(INPUT_LABEL_EXPR, True, 36, 13, GREY))

    def source_button(self, mode, me, inp):
        if mode == "PVW":
            ctl = self.fresh(self.pvw)
        elif mode == "CUT":
            ctl = self.fresh(self.cut)
        else:  # AUTO and HOT start from the PVW-wait-AUTO button
            ctl = self.fresh(self.auto)
        for f in ctl["feedbacks"]:
            self.localize(f)
        acts = ctl["steps"]["0"]["action_sets"]["down"]
        for a in acts:
            if a.get("connectionId") == self.conn:
                self.localize(a)
        if mode == "HOT":
            cut = self.localize(self.fresh(next(a for a in self.cut_t["steps"]["0"]["action_sets"]["down"])))
            wait = self.fresh(self.wait)
            wait["options"]["time"] = wrap("100", True)
            pv = next(a for a in acts if a["definitionId"] == "preview")
            ctl["steps"]["0"]["action_sets"]["down"] = [pv, wait, cut]
        self.set_locals(ctl, me, inp)
        self.style_source(ctl, mode)
        return ctl

    def transition_button(self, which, me):
        ctl = self.fresh(self.cut_t if which == "CUT" else self.auto_t)
        self.set_locals(ctl, me)
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(MODES[which][2])
        return ctl

    def nav_button(self, target, image=None):
        ctl = self.fresh(self.nav)
        for a in ctl["steps"]["0"]["action_sets"]["down"]:
            if a["definitionId"] == "set_page":
                a["options"]["page"] = wrap(target)
        if image:
            for l in ctl["style"]["layers"]:
                if l["id"] == "image0":
                    l["base64Image"] = wrap(image)
        return ctl

    def readout(self, bus, me):
        """Live PGM / PVW source name for this M/E (display only)."""
        ctl = self.fresh(self.cut_t)
        ctl["feedbacks"] = []
        ctl["steps"]["0"]["action_sets"]["down"] = []
        self.set_locals(ctl, me)
        color = PGM_RED if bus == "pgm" else PVW_GREEN
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(color)
            elif l["id"] == "text0":
                l["text"] = wrap(f"$(ATEM:{bus}$(local:me)_input)")
                l["fontsize"] = wrap(26)
                l["y"] = wrap(8)
        ctl["style"]["layers"].append(self.text_layer(bus.upper(), False, -34, 14, color))
        return ctl

    # ------------------------------------------------ show-builder extras

    def _blank(self, me=None):
        """Plain black control with the example's layer stack and local `me`."""
        ctl = self.fresh(self.cut_t)
        ctl["feedbacks"] = []
        ctl["steps"]["0"]["action_sets"]["down"] = []
        if me is not None:
            self.set_locals(ctl, me)
        else:
            ctl["localVariables"] = []
        return ctl

    def title_button(self, text, me):
        """M/E title key: Rob's own name for the bus (RECORDS, PROGRAM, SCREENS...)."""
        ctl = self._blank(me)
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(TITLE_COLOR)
            elif l["id"] == "text0":
                l["text"] = wrap(text)
                l["fontsize"] = wrap(24)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(6)
        ctl["style"]["layers"].append(self.text_layer('concat("M/E ", $(local:me))', True, -34, 13, TITLE_COLOR))
        return ctl

    def _local(self, name, value):
        lv = copy.deepcopy(next(l for l in self.pvw["localVariables"] if l["variableName"] == "me"))
        lv["id"] = nid()
        lv["variableName"] = name
        lv["options"]["startup_value"] = wrap(value)
        return lv

    def aux_button(self, aux, inp):
        """Route `input` to AUX `aux` (bmd-atem 4.x `aux` action/feedback, 1-based)."""
        if not self.aux_donor:
            raise ValueError("AUX buttons need the AUX donor (donor-atem-aux.json)")
        ctl = self.fresh(self.pvw)
        ctl["localVariables"] = [self._local("aux", aux), self._local("input", inp)]
        act = self.localize(self.fresh(self.aux_donor["action"]))
        act.pop("disabled", None)
        fb = self.localize(self.fresh(self.aux_donor["feedback"]))
        fb.pop("disabled", None)
        for o in fb["styleOverrides"]:
            o["override"] = wrap(AUX_ON if o["elementId"] == "box0" else 0xFFFFFF)
        ctl["feedbacks"] = [fb]
        ctl["steps"]["0"]["action_sets"]["down"] = [act]
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(AUX_COLOR)
                l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["base64Image"] = wrap(self.glyphs["AUX"])
                l["x"], l["y"] = wrap(7), wrap(7)
                l["width"], l["height"] = wrap(22), wrap(22)
                l["halign"], l["valign"] = wrap("left"), wrap("top")
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["fontsize"] = wrap(30)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2)
        ctl["style"]["layers"].append(self.text_layer(aux_name_expr("$(local:aux)"), True, -37, 13, AUX_COLOR, x=9))
        ctl["style"]["layers"].append(self.text_layer('concat("TO AUX ", $(local:aux))', True, 36, 12, GREY))
        return ctl

    def ss_box_button(self, ss, box, inp):
        """Put `input` into SuperSource `ss` box `box` (bmd-atem 4.x
        setSsrcBoxSource / ssrc_box_source; ssrcId and boxIndex are 1-based)."""
        if not self.ss_donor:
            raise ValueError("SuperSource keys need the donor (donor-atem-ssrc.json)")
        ctl = self.fresh(self.pvw)
        ctl["localVariables"] = [self._local("ss", ss), self._local("box", box), self._local("input", inp)]
        act = self.localize(self.fresh(self.ss_donor["action"])); act.pop("disabled", None)
        fb = self.localize(self.fresh(self.ss_donor["feedback"])); fb.pop("disabled", None)
        for o in fb["styleOverrides"]:
            o["override"] = wrap(SS_COLOR if o["elementId"] == "box0" else 0xFFFFFF)
        ctl["feedbacks"] = [fb]
        ctl["steps"]["0"]["action_sets"]["down"] = [act]
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(SS_COLOR)
                l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["base64Image"] = wrap(self.glyphs["SS"])
                l["x"], l["y"] = wrap(7), wrap(7)
                l["width"], l["height"] = wrap(20), wrap(20)
                l["halign"], l["valign"] = wrap("left"), wrap("top")
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["fontsize"] = wrap(30)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2)
        tag = self.text_layer('concat("SS", $(local:ss), " BOX ", $(local:box))', True, -37, 12, SS_COLOR, x=9)
        ctl["style"]["layers"].append(tag)
        ctl["style"]["layers"].append(self.text_layer(INPUT_LABEL_EXPR, True, 36, 12, GREY))
        fb["styleOverrides"].append({"overrideId": nid(), "elementId": tag["id"], "elementProperty": "color",
                                     "override": wrap(0xFFFFFF)})    # teal tag would vanish on the teal fill
        return ctl

    def ss_box_readout(self, ss, box):
        """Display only: what is in SuperSource `ss` box `box` right now."""
        ctl = self._blank()
        ctl["localVariables"] = [self._local("ss", ss), self._local("box", box)]
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(SS_COLOR)
            elif l["id"] == "text0":
                l["text"] = wrap("$(ATEM:ssrc$(local:ss)_box$(local:box)_source)")
                l["fontsize"] = wrap(26)
                l["y"] = wrap(8)
        ctl["style"]["layers"].append(self.text_layer('concat("SS", $(local:ss), " BOX ", $(local:box))', True, -34, 13, SS_COLOR))
        return ctl

    def aux_readout(self, aux):
        """Display only: what is on AUX `aux` right now."""
        ctl = self._blank()
        ctl["localVariables"] = [self._local("aux", aux)]
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(AUX_COLOR)
            elif l["id"] == "text0":
                l["text"] = wrap("$(ATEM:aux$(local:aux)_input)")
                l["fontsize"] = wrap(26)
                l["y"] = wrap(8)
        ctl["style"]["layers"].append(self.text_layer(aux_name_expr("$(local:aux)"), True, -34, 14, AUX_COLOR))
        return ctl

    @staticmethod
    def scroll_map(idx, hi, extra):
        """Scroll position -> input number: lo..hi are inputs, then `extra` ids."""
        out = str(extra[-1]) if extra else idx
        for n, i in reversed(list(enumerate(extra[:-1], start=hi + 1))):
            out = f"({idx} == {n} ? {i} : {out})"
        return f"({idx} <= {hi} ? {idx} : {out})" if extra else idx

    def dial(self, func, target, lo, hi, extra=()):
        """+ XL encoder plus the strip segment above it. Rotate scrolls inputs
        lo..hi in a custom variable (created on first turn); press - or a tap on
        the strip - sends the choice: AUX route, M/E preview, or M/E program."""
        var = f"sb_{func}{target}"
        idx = f"($(custom:{var}) ?? {lo})"
        extra = list(extra) if func == "aux" else []
        cur = self.scroll_map(idx, hi, extra)
        top = hi + len(extra)
        pick = wrap(cur, True)

        def set_var(expr):
            return {"type": "action", "id": nid(), "connectionId": "internal",
                    "definitionId": "custom_variable_set_value",
                    "options": {"name": wrap(var), "create": wrap(True), "value": wrap(expr, True)},
                    "children": {}}

        if func == "aux":
            act = self.fresh(self.aux_donor["action"])
            act.pop("disabled", None)
            act["options"]["aux"] = wrap(target)
            act["options"]["input"] = pick
            fb = self.fresh(self.aux_donor["feedback"])
            fb.pop("disabled", None)
            fb["options"]["aux"] = wrap(target)
            fb["options"]["input"] = pick
            for o in fb["styleOverrides"]:
                o["override"] = wrap(AUX_ON if o["elementId"] == "box0" else 0xFFFFFF)
            fbs = [fb]
            head = f'concat({aux_name_expr(str(target))}, "  AUX {target}")'
            now = f"ON AUX: $(ATEM:aux{target}_input)"
        else:
            src = self.pvw if func == "pvw" else self.cut
            act = self.fresh(next(a for a in src["steps"]["0"]["action_sets"]["down"]
                                  if a["definitionId"] in ("preview", "program")))
            act["options"]["mixeffect"] = wrap(target)
            act["options"]["input"] = pick
            fbs = []
            for f in self.fresh(self.pvw)["feedbacks"]:   # green in preview, red on program
                f["options"]["mixeffect"] = wrap(target)
                f["options"]["input"] = pick
                fbs.append(f)
            head = f'"M/E {target}  {DIAL_FUNCS[func][0]}"'
            now = f"PGM: $(ATEM:pgm{target}_input)" if func == "cut" else f"PVW: $(ATEM:pvw{target}_input)"

        strip = self._blank()
        strip["feedbacks"] = fbs
        strip["steps"]["0"]["action_sets"]["down"] = [act]
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(strip_art(func))
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(f'parseVariables(concat("$", "(ATEM:short_", {cur}, ")"), concat("IN ", {cur}))', True)
                l["fontsize"] = wrap(28)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(0)
                l["height"] = wrap(100)
        strip["style"]["layers"].append(self.text_layer(head, True, -23, 13, DIAL_FUNCS[func][1]))
        strip["style"]["layers"].append(self.text_layer(now, False, 22, 11, GREY))

        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        knob["steps"]["0"]["action_sets"].update({
            "down": [self.fresh(act)],
            "rotate_left": [set_var(f"max({lo}, {idx} - 1)")],
            "rotate_right": [set_var(f"min({top}, {idx} + 1)")],
        })
        return strip, knob

    @staticmethod
    def _set_var(var, expr):
        return {"type": "action", "id": nid(), "connectionId": "internal",
                "definitionId": "custom_variable_set_value",
                "options": {"name": wrap(var), "create": wrap(True), "value": wrap(expr, True)},
                "children": {}}

    def aux_pair(self, key, aux_hi, lo, hi, extra=()):
        """Two + XL dials that work together. Left: turn to choose the AUX
        (1..aux_hi). Right: turn to choose the source (lo..hi). Pressing either
        dial, or tapping either strip, routes that source to that AUX."""
        sel, src = f"sb_{key}_aux", f"sb_{key}_src"
        a = f"($(custom:{sel}) ?? 1)"
        si = f"($(custom:{src}) ?? {lo})"
        i = self.scroll_map(si, hi, list(extra))
        send = self.fresh(self.aux_donor["action"])
        send.pop("disabled", None)
        send["options"]["aux"] = wrap(a, True)
        send["options"]["input"] = wrap(i, True)
        fb = self.fresh(self.aux_donor["feedback"])
        fb.pop("disabled", None)
        fb["options"]["aux"] = wrap(a, True)
        fb["options"]["input"] = wrap(i, True)
        for o in fb["styleOverrides"]:
            o["override"] = wrap(AUX_ON if o["elementId"] == "box0" else 0xFFFFFF)
        aux_name = aux_name_expr(a)
        on_aux = f'parseVariables(concat("$", "(ATEM:aux", {a}, "_input)"), "-")'
        src_name = f'parseVariables(concat("$", "(ATEM:short_", {i}, ")"), concat("IN ", {i}))'

        def strip(head, big, foot):
            t = self._blank()
            t["feedbacks"] = [self.fresh(fb)]
            t["steps"]["0"]["action_sets"]["down"] = [self.fresh(send)]
            for l in t["style"]["layers"]:
                if l["id"] == "box0":
                    l["color"] = wrap(DARK)
                elif l["id"] == "image0":
                    l["base64Image"] = wrap(strip_art("aux"))
                    l["fillMode"] = wrap("fit")
                elif l["id"] == "text0":
                    l["text"] = wrap(big, True)
                    l["fontsize"] = wrap(28)
                    l["fontsizeAllowShrink"] = wrap(True)
                    l["y"] = wrap(0)
            t["style"]["layers"].append(self.text_layer(head, True, -23, 13, AUX_COLOR))
            t["style"]["layers"].append(self.text_layer(foot, True, 22, 11, GREY))
            return t

        def knob(var, first, last, cur):
            k = self._blank()
            for l in k["style"]["layers"]:
                if l["id"] == "text0":
                    l["text"] = wrap("")
            k["options"]["rotaryActions"] = True
            k["steps"]["0"]["action_sets"].update({
                "down": [self.fresh(send)],
                "rotate_left": [self._set_var(var, f"max({first}, {cur} - 1)")],
                "rotate_right": [self._set_var(var, f"min({last}, {cur} + 1)")],
            })
            return k

        strip_a = strip('"AUX SELECT"', aux_name, f'concat("NOW: ", {on_aux})')
        strip_b = strip(f'concat("TO ", {aux_name})', src_name, f'concat("AUX ", {a}, " SOURCE")')
        return strip_a, knob(sel, 1, aux_hi, a), strip_b, knob(src, lo, hi + len(extra), si)

    @staticmethod
    def resolve_locals(ctl):
        """A key's actions/feedbacks with every $(local:x) replaced by that local's value,
        so they still work once moved off the key (onto a list dial)."""
        vals = {lv["variableName"]: (lv.get("options", {}).get("startup_value") or {}).get("value")
                for lv in ctl.get("localVariables", [])}
        o = copy.deepcopy(ctl)

        def walk(x):
            if isinstance(x, dict):
                for k, v in x.items():
                    if isinstance(v, str) and "$(local:" in v:
                        for name, val in vals.items():
                            v = v.replace(f"$(local:{name})", str(val))
                        x[k] = v
                    else:
                        walk(v)
            elif isinstance(x, list):
                for v in x:
                    walk(v)
        walk(o)
        return o

    def list_dial(self, key, title, items):
        """+ XL encoder that holds a list of keys. Turn to step through them (the strip
        shows the current one, lit green/red like the key would be), press the dial or
        tap the strip to run that key's press. `items`: [(control, label, sub)]."""
        var = f"sb_{key}"
        n = len(items)
        idx = f"($(custom:{var}) ?? 1)"
        ctls = [self.fresh(self.resolve_locals(c)) for c, _, _ in items]

        def cond(i):
            return {"type": "feedback", "id": nid(), "definitionId": "variable_value", "connectionId": "internal",
                    "options": {"variable": wrap(f"custom:{var}"), "op": wrap("eq"), "value": wrap(str(i))},
                    "isInverted": wrap(False)}

        def run():
            node = []
            for i in range(n, 0, -1):
                acts = self.fresh(ctls[i - 1]["steps"]["0"]["action_sets"].get("down") or [])
                node = [{"type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal",
                         "options": {}, "children": {"condition": [cond(i)], "actions": acts, "else_actions": node}}]
            return node

        fbs = []
        for i, c in enumerate(ctls, start=1):
            for f in c.get("feedbacks", []):
                if not f.get("styleOverrides"):
                    continue
                inner = self.fresh(f)
                ov = inner.pop("styleOverrides")
                ov = [o for o in ov if o["elementId"] in ("box0", "text0")]   # the strip has no tag/label layers
                fbs.append({"type": "feedback", "id": nid(), "definitionId": "logic_operator", "connectionId": "internal",
                            "options": {"operation": wrap("and")}, "isInverted": wrap(False),
                            "children": {"default": [cond(i), inner]}, "styleOverrides": ov})

        def pick(texts):
            out = json.dumps(texts[0])
            for i in range(2, n + 1):
                out = f"({idx} == {i} ? {json.dumps(texts[i - 1])} : {out})"
            return out

        labels = pick([lbl for _, lbl, _ in items])
        subs = pick([sub for _, _, sub in items])
        strip = self._blank()
        strip["feedbacks"] = fbs
        strip["steps"]["0"]["action_sets"]["down"] = run()
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(strip_art("list"))
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(labels, True)
                l["fontsize"] = wrap(28)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(0)
                l["height"] = wrap(100)
        strip["style"]["layers"].append(self.text_layer(json.dumps(title), True, -23, 13, DIAL_FUNCS["list"][1]))
        strip["style"]["layers"].append(self.text_layer(f'concat({subs}, "  ", {idx}, "/{n}")', True, 22, 11, GREY))

        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        knob["steps"]["0"]["action_sets"].update({
            "down": run(),
            "rotate_left": [self._set_var(var, f"max(1, {idx} - 1)")],
            "rotate_right": [self._set_var(var, f"min({n}, {idx} + 1)")],
        })
        return strip, knob

    def tbar_dial(self, me, step=5):
        """+ XL encoder as an M/E T-bar. The handle position lives in custom var sb_tbar{me}
        (0..100) and is sent with the module's tBar action, like a real lever: turn right to
        push it to 100 (the transition completes), then the strip arrow flips and you turn
        left back to 0 for the next one. sb_tbar{me}_dir = 0 (arrow right) / 1 (arrow left).
        Press (or tap the strip) = AUTO; mid-move it also parks the handle at the far end."""
        step = max(1, min(25, int(step)))
        pos, dvar = f"sb_tbar{me}", f"sb_tbar{me}_dir"
        h = f"($(custom:{pos}) ?? 0)"

        def cmp(var, op, val):
            return {"type": "feedback", "id": nid(), "definitionId": "variable_value", "connectionId": "internal",
                    "options": {"variable": wrap(f"custom:{var}"), "op": wrap(op), "value": wrap(str(val))},
                    "isInverted": wrap(False)}

        def iff(conds, then, other=()):
            cond = conds[0] if len(conds) == 1 else {
                "type": "feedback", "id": nid(), "definitionId": "logic_operator", "connectionId": "internal",
                "options": {"operation": wrap("and")}, "isInverted": wrap(False), "children": {"default": conds}}
            return {"type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal", "options": {},
                    "children": {"condition": [cond], "actions": list(then), "else_actions": list(other)}}

        def tbar(expr, is_expr=True):
            return {"type": "action", "id": nid(), "connectionId": self.conn, "definitionId": "tBar",
                    "options": {"mixeffect": wrap(me), "position": wrap(expr, is_expr), "fadeDuration": wrap(0),
                                "fadeAlgorithm": wrap("linear"), "fadeCurve": wrap("ease-in")},
                    "upgradeIndex": 10, "children": {}}

        def setv(var, expr):
            return self._set_var(var, str(expr))

        # tBar is listed before the variable write so it reads the old position either way
        # (whether Companion runs a set's actions in order or together).
        right = [iff([cmp(pos, "ne", 100)], [
            iff([cmp(pos, "gt", 99 - step)],
                [tbar(100, False), setv(pos, 100), setv(dvar, 1)],
                [tbar(f"min(100, {h} + {step})"), setv(pos, f"min(100, {h} + {step})")])])]
        left = [iff([cmp(pos, "gt", 0)], [
            iff([cmp(pos, "lt", step + 1)],
                [tbar(0, False), setv(pos, 0), setv(dvar, 0)],
                [tbar(f"max(0, {h} - {step})"), setv(pos, f"max(0, {h} - {step})")])])]
        auto = self.fresh(next(a for a in self.auto_t["steps"]["0"]["action_sets"]["down"] if a["definitionId"] == "auto"))
        auto["options"]["mixeffect"] = wrap(me)
        park = iff([cmp(pos, "gt", 0), cmp(pos, "lt", 100)],
                   [iff([cmp(dvar, "eq", 1)], [setv(pos, 0), setv(dvar, 0)], [setv(pos, 100), setv(dvar, 1)])])
        press = [auto, park]

        color = DIAL_FUNCS["tbar"][1]
        strip = self._blank()
        strip["steps"]["0"]["action_sets"]["down"] = self.fresh(press)
        is_left = f"($(custom:{dvar}) ?? 0) == 1"
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(tbar_art(False))
                l["fillMode"] = wrap("fit")
                l["enabled"] = wrap(f"!({is_left})", True)
            elif l["id"] == "text0":
                l["text"] = wrap(f'concat({h}, "%")', True)
                l["fontsize"] = wrap(30)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(0)
                l["height"] = wrap(100)
        img = next(l for l in strip["style"]["layers"] if l["id"] == "image0")
        back = copy.deepcopy(img)
        back["id"] = nid()
        back["base64Image"] = wrap(tbar_art(True))
        back["enabled"] = wrap(is_left, True)
        strip["style"]["layers"].insert(strip["style"]["layers"].index(img) + 1, back)
        strip["style"]["layers"].append(self.text_layer(
            f'concat("M/E {me}  T-BAR  ", {is_left} ? "<<<" : ">>>")', True, -23, 13, color))
        strip["style"]["layers"].append(self.text_layer(
            f'concat("PVW ", $(ATEM:pvw{me}_input), "  >  PGM ", $(ATEM:pgm{me}_input))', True, 22, 11, GREY))

        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        knob["steps"]["0"]["action_sets"].update({"down": self.fresh(press), "rotate_left": left, "rotate_right": right})
        return strip, knob

    # ------------------------------------------------------------ flying key
    FLY_COLOR = 0x9BE15D                 # flying-key keys (lime: unused elsewhere)
    FLY_EASINGS = ("linear", "quadratic", "cubic", "quartic", "quintic", "sinusoidal", "exponential",
                   "circular", "elastic", "back", "bounce")
    FLY_ARROW = {"right": "<", "left": ">", "top": "v", "bottom": "^"}    # direction of travel, as drawn

    def _usk(self, defn, me, key, **opts):
        o = {"mixeffect": wrap(me), "key": wrap(key)}
        o.update({k: (v if isinstance(v, dict) and "value" in v else wrap(v)) for k, v in opts.items()})
        return {"type": "action", "id": nid(), "connectionId": self.conn, "definitionId": defn,
                "options": o, "upgradeIndex": 10, "children": {}}

    def _dve(self, me, key, x, y, size, rate=0, easing="linear", curve="ease-in"):
        return self._usk("uskDveProperties", me, key, **{**DVE_DEFAULTS, "properties": ["positionX", "positionY", "sizeX", "sizeY"],
                         "transitionRate": int(rate), "transitionEasing": easing, "transitionCurve": curve,
                         "positionX": round(x, 3), "positionY": round(y, 3), "sizeX": size, "sizeY": size})

    def _wait(self, ms):
        w = self.fresh(self.wait)
        w["options"]["time"] = wrap(str(int(ms)), True)
        return w

    @staticmethod
    def fly_arrow_png(frm, color):
        """22x22 arrow showing the direction the key travels in."""
        im = Image.new("RGBA", (44, 44), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = rgb(color) + (255,)
        d.rectangle((8, 19, 34, 25), fill=c); d.polygon([(26, 10), (40, 22), (26, 34)], fill=c)    # points right
        rot = {"left": 0, "right": 180, "top": 270, "bottom": 90}[frm]                              # travel direction
        return png_uri(im.rotate(rot).resize((22, 22), Image.LANCZOS))

    def fly_key_button(self, me, key, fill, cut, frm="right", exit="through", ms=700, easing="cubic",
                       size=1.0, x=0.0, y=0.0, label="", ktype="dve", premult=True, clip=10, gain=50):
        """One key flies a source in through upstream key `key` and, pressed again, flies it out.
        In: set inputs, DVE type, jump off-screen on the `frm` side (no animation), wait for the switcher
        to confirm, key on, then glide to (x, y) with ease-out. Out: glide off-screen (`exit` "back" =
        the side it came from, "through" = the far side) with ease-in, then key off and park it.
        ktype "luma" keys out black instead of using the source's alpha: luma type, self-keyed (cut =
        fill), pre-multiplied or clip/gain, with Flying Key switched on so the same DVE moves apply.
        The glide is the bmd-atem module's own tween (uskDveProperties transitionRate/Easing/Curve),
        which starts from the module's last known position - hence the waits."""
        size = max(0.05, min(1.0, float(size)))
        hx, hy = 16 + 16 * size + 0.5, 9 + 9 * size + 0.5                 # fully off frame, centre to edge
        side = {"right": (hx, y), "left": (-hx, y), "top": (x, hy), "bottom": (x, -hy)}
        opposite = {"right": "left", "left": "right", "top": "bottom", "bottom": "top"}
        sx, sy = side[frm]
        ex, ey = side[frm if exit == "back" else opposite[frm]]
        easing = easing if easing in self.FLY_EASINGS else "cubic"
        ms = max(0, min(10000, int(ms)))
        if ktype == "luma":
            keyer = [self._usk("uskSource", me, key, fill=fill, cut=cut), self._usk("uskType", me, key, type="luma"),
                     self._usk("uskLumaProperties", me, key, properties=["preMultiplied", "clip", "gain", "invert"],
                               preMultiplied=bool(premult), clip=float(clip), gain=float(gain), invert=False),
                     self._usk("uskFlyKeyLumaChromaPattern", me, key, properties=["flyEnabled"], flyEnabled=True,
                               positionX=0, positionY=0, sizeX=1, sizeY=1)]
        else:
            keyer = [self._usk("uskSource", me, key, fill=fill, cut=cut), self._usk("uskType", me, key, type="dve")]
        fly_in = keyer + [
                  self._dve(me, key, sx, sy, size), self._wait(80),
                  self._usk("uskOnAir", me, key, onair="true"), self._wait(40),
                  self._dve(me, key, x, y, size, ms, easing, "ease-out")]
        fly_out = [self._dve(me, key, ex, ey, size, ms, easing, "ease-in"), self._wait(ms + 60),
                   self._usk("uskOnAir", me, key, onair="false")]
        on_air = {"type": "feedback", "id": nid(), "definitionId": "uskOnAir", "connectionId": self.conn,
                  "options": {"mixeffect": wrap(me), "key": wrap(key)}, "isInverted": wrap(False), "upgradeIndex": 10}
        ctl = self._blank()
        color = self.FLY_COLOR
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(color); l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["base64Image"] = wrap(self.fly_arrow_png(frm, color))
                l["x"], l["y"] = wrap(7), wrap(7); l["width"], l["height"] = wrap(20), wrap(20)
                l["halign"], l["valign"] = wrap("left"), wrap("top"); l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                big = label or f'parseVariables(concat("$", "(ATEM:short_", {fill}, ")"), "IN {fill}")'
                l["text"] = wrap(big, not label)
                l["fontsize"] = wrap(26); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(2)
        tag = self.text_layer(f"FLY M{me} K{key}", False, -37, 12, color, x=9)
        foot = self.text_layer(f"{frm.upper()} · {'LUMA' if ktype == 'luma' else easing.upper()[:5]}", False, 36, 11, GREY)
        ctl["style"]["layers"] += [tag, foot]
        fb = copy.deepcopy(on_air)
        fb["styleOverrides"] = [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(color)}] + \
            [{"overrideId": nid(), "elementId": i, "elementProperty": "color", "override": wrap(0x000000)}
             for i in ("text0", tag["id"], foot["id"])]
        ctl["feedbacks"] = [fb]
        cond = copy.deepcopy(on_air); cond["id"] = nid()
        ctl["steps"]["0"]["action_sets"]["down"] = [{
            "type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal", "options": {},
            "children": {"condition": [cond], "actions": fly_out, "else_actions": fly_in}}]
        return ctl

    # ------------------------------------------------------------ Cue Dial camera control (URSA)
    # A Cue Dial (Downstage Cue, knobnet) sits on the camera over Bluetooth and serves a small
    # web API on the network: GET /c?x=<command>&k=<the Dial's key> runs a command as if the knob
    # had (`step <p> <+n|-n>`, `fine <p>`; p = the Dial's page: 0 IRIS, 1 GAIN), and GET /s is
    # what the Dial shows: {"dial":{"p":[{"n":"IRIS","v":"f/4.5","fine":1},...],"local":0,"link":5}}.
    # Companion sends both through a Generic HTTP connection labelled "dials"; every press reads
    # /s back into custom variable dial<n>_s, and the strips and keys show it with jsonpath.
    # Steps, never absolutes: the Dial clamps at the operator's stops and two hands never fight.
    DIALS_CONN = "cueDialsHttp00000001"           # stand-in id: Send maps it to the One's "dials"
    DIALS_INSTANCE = {"moduleInstanceType": "connection", "moduleId": "generic-http", "moduleVersionId": "3.2.0",
                      "updatePolicy": "stable", "sortOrder": 50, "label": "dials", "isFirstInit": False, "secrets": {},
                      "lastUpgradeIndex": -1, "enabled": True, "config": {"prefix": "", "proxyAddress": ""}}
    CAM_SET = {"iris": (0, "IRIS", 0xF5A524), "gain": (1, "GAIN", 0x2FD97B)}    # the Dial's own page colours

    def _http_get(self, url, var=""):
        return {"type": "action", "id": nid(), "connectionId": self.DIALS_CONN, "definitionId": "get",
                "options": {"url": wrap(url), "header": wrap(""), "jsonResultDataVariable": wrap(var),
                            "result_stringify": wrap(False), "statusCodeVariable": wrap("")},
                "upgradeIndex": -1, "children": {}}

    def _cam_cmd(self, n, ip, key, cmd):
        """Run a Dial command, then read the Dial back into dial<n>_s (after it has told the camera)."""
        from urllib.parse import quote
        base = f"http://{ip}"
        var = f"dial{n}_s"
        return [self._set_var(var, f"$(custom:{var}) ?? \"\""),         # makes the variable on first use
                self._http_get(f"{base}/c?x={quote(cmd)}&k={quote(key)}"),
                self._wait(250), self._http_get(f"{base}/s", var)]

    def _cam_read(self, n, ip):
        var = f"dial{n}_s"
        return [self._set_var(var, f"$(custom:{var}) ?? \"\""), self._http_get(f"http://{ip}/s", var)]

    @staticmethod
    def _cam_val(n, p):
        return f'jsonpath($(custom:dial{n}_s), "$.dial.p[{p}].v") ?? "--"'

    @staticmethod
    def _cam_foot(n, p):
        s = f"$(custom:dial{n}_s)"
        return (f'(jsonpath({s}, "$.dial.link") ?? "") == "" ? "NO DIAL" : '
                f'(jsonpath({s}, "$.dial.local") == 1 ? "LOCAL" : '
                f'(jsonpath({s}, "$.dial.p[{p}].fine") == 1 ? "FINE" : ""))')

    def cam_dial(self, n, ip, key, setting, name=""):
        """+ XL encoder on one camera setting: turn = a step each detent, press = fine on/off,
        tap the strip = read the Dial again. The strip shows the value as the Dial does."""
        p, label, color = self.CAM_SET[setting]
        head = f"{name or f'CAM {n}'} {label}"[:20]
        strip = self._blank()
        strip["steps"]["0"]["action_sets"]["down"] = self._cam_read(n, ip)
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(strip_art(None, color)); l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(self._cam_val(n, p), True)
                l["fontsize"] = wrap(30); l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2); l["height"] = wrap(100)
        strip["style"]["layers"].append(self.text_layer(json.dumps(head), True, -23, 13, color))
        strip["style"]["layers"].append(self.text_layer(self._cam_foot(n, p), True, 22, 11, GREY))
        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        knob["steps"]["0"]["action_sets"].update({
            "down": self._cam_cmd(n, ip, key, f"fine {p}"),
            "rotate_left": self._cam_cmd(n, ip, key, f"step {p} -1"),
            "rotate_right": self._cam_cmd(n, ip, key, f"step {p} 1"),
        })
        return strip, knob

    def cam_key(self, n, ip, key, setting, act, name=""):
        """A key for decks without dials: act "up" / "down" (one step; iris up = closes, as the
        Dial counts), "fine" (fine on/off) or "show" (the value; press reads the Dial again)."""
        p, label, color = self.CAM_SET[setting]
        ctl = self._blank()
        cmd = {"up": f"step {p} 1", "down": f"step {p} -1", "fine": f"fine {p}"}.get(act)
        ctl["steps"]["0"]["action_sets"]["down"] = self._cam_cmd(n, ip, key, cmd) if cmd else self._cam_read(n, ip)
        big = {"up": '"+"', "down": '"−"', "fine": '"FINE"'}.get(act, self._cam_val(n, p))
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(color); l["borderPosition"] = wrap("inside")
            elif l["id"] == "text0":
                l["text"] = wrap(big, True)
                l["fontsize"] = wrap(40 if act in ("up", "down") else 22); l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(4)
        ctl["style"]["layers"].append(self.text_layer(json.dumps(f"{name or f'CAM {n}'} {label}"[:16]), True, -34, 11, color))
        foot = self._cam_val(n, p) if act in ("up", "down", "fine") else self._cam_foot(n, p)
        ctl["style"]["layers"].append(self.text_layer(foot, True, 34, 11, GREY))
        return ctl

    # ------------------------------------------------------------ Combo key
    COMBO_COLOR = 0xC77DFF

    def combo_key(self, label, tasks, lit=None):
        """One press runs several keys' press actions in order. `tasks`: a built control, or
        an int (a wait in ms). `lit`: index of the task whose light this key copies, or None."""
        down, feedbacks, n = [], [], 0
        for i, t in enumerate(tasks):
            if isinstance(t, int):
                down.append(self._wait(t))
                continue
            n += 1
            c = self.fresh(self.resolve_locals(t))
            down += c["steps"]["0"]["action_sets"].get("down") or []
            if i == lit:
                for f in c.get("feedbacks", []):
                    ov = [o for o in f.get("styleOverrides") or [] if o["elementId"] in ("box0", "text0")]
                    if ov:
                        feedbacks.append(dict(f, styleOverrides=ov))
        ctl = self._blank()
        ctl["steps"]["0"]["action_sets"]["down"] = down
        ctl["feedbacks"] = feedbacks
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(self.COMBO_COLOR); l["borderPosition"] = wrap("inside")
            elif l["id"] == "text0":
                l["text"] = wrap(label); l["fontsize"] = wrap(22); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(2)
        ctl["style"]["layers"] += [self.text_layer("COMBO", False, -34, 11, self.COMBO_COLOR),
                                   self.text_layer(f"{n} TASKS", False, 34, 11, GREY)]
        return ctl

    # ------------------------------------------------------------ XR18 ambient (behringer-xair)
    # Option ids are from the module's source (v3.0.1), not cloned from a live button: it isn't
    # installed anywhere yet. That module has mute, fader and gate on/off, with no action for gate
    # range / threshold / hold / release and no raw-OSC action, so the kit has no dials for those.
    XAIR_CONN = "xr18XairConn00000001"            # stand-in id: Send maps it to the behringer-xair connection
    XAIR_INSTANCE = {"moduleInstanceType": "connection", "moduleId": "behringer-xair", "moduleVersionId": "3.0.1",
                     "updatePolicy": "stable", "sortOrder": 51, "label": "xair", "isFirstInit": False, "secrets": {},
                     "lastUpgradeIndex": 6, "enabled": True, "config": {"host": "", "faderMax": "0.75", "scan": True}}
    XAIR_COLOR = 0x38C7E8
    XAIR_HOLD = 1000                              # ms a guarded key must be held

    def _xa(self, defn, **opts):
        return {"type": "action", "id": nid(), "connectionId": self.XAIR_CONN, "definitionId": defn,
                "options": {k: wrap(v) for k, v in opts.items()}, "upgradeIndex": 6, "children": {}}

    def _xa_fb(self, defn, overrides, **opts):
        return {"type": "feedback", "id": nid(), "connectionId": self.XAIR_CONN, "definitionId": defn,
                "options": {k: wrap(v) for k, v in opts.items()}, "isInverted": wrap(False), "upgradeIndex": 6,
                "styleOverrides": overrides}

    def _xa_step(self, ch, ticks):
        return self._xa("fad_a", type="/ch/", num=int(ch), ticks=str(ticks), duration=0, faderLim=True)

    @staticmethod
    def _xa_db(label, ch):
        return f'concat($({label}:f_ch{int(ch)}_d) ?? "--", " dB")'

    def _status_key(self, head, sets, fbs, foot_expr=None, hold=False):
        """Key with a big state word that only a feedback can light. Each entry of `fbs` is
        (defn, opts, fill, word colour, word): no answer from the mixer leaves it dark and grey."""
        ctl = self._blank()
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(GREY); l["borderPosition"] = wrap("inside")
            elif l["id"] == "text0":
                l["text"] = wrap(head); l["fontsize"] = wrap(15); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(-27)
        foot = self.text_layer(foot_expr or json.dumps("HOLD 1 S" if hold else ""), True, 34, 11, GREY)
        ctl["style"]["layers"].append(foot)
        ctl["feedbacks"] = []
        for defn, opts, fill, ink, word in fbs:
            w = self.text_layer(word, False, 4, 22, DARK)
            ctl["style"]["layers"].append(w)
            ov = [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(fill)},
                  {"overrideId": nid(), "elementId": "box0", "elementProperty": "borderColor", "override": wrap(fill)}]
            ov += [{"overrideId": nid(), "elementId": i, "elementProperty": "color", "override": wrap(ink)}
                   for i in ("text0", foot["id"], w["id"])]
            ctl["feedbacks"].append(self._xa_fb(defn, ov, **opts))
        if hold:                                  # nothing on a tap; fires once the hold time is reached
            ctl["steps"]["0"]["action_sets"]["down"] = []
            ctl["steps"]["0"]["action_sets"][str(self.XAIR_HOLD)] = sets
            ctl["steps"]["0"]["options"]["runWhileHeld"] = [self.XAIR_HOLD]
        else:
            ctl["steps"]["0"]["action_sets"]["down"] = sets
        return ctl

    def xair_key(self, act, house, shot, step, label="xair"):
        """AMBIENT MUTE, AMBIENT + / -, HOUSE MUTE and MAIN MUTE (held), DUCK ON/OFF."""
        ON, OFF, WARN = 0x18B85A, 0xD92B2B, 0xF5A524
        ink = 0x000000
        def mute_fbs(defn, **o):
            return [(defn, dict(o, state="0"), ON, ink, "ON AIR"), (defn, dict(o, state="1"), OFF, 0xFFFFFF, "MUTED")]
        if act == "ambmute":
            return self._status_key("AMBIENT", [self._xa("mute", type="/ch/", num=int(shot), mute="2")],
                                    mute_fbs("ch", theChannel=int(shot)), self._xa_db(label, shot))
        if act == "housemute":
            return self._status_key("HOUSE", [self._xa("mute", type="/ch/", num=int(house), mute="2")],
                                    mute_fbs("ch", theChannel=int(house)), hold=True)
        if act == "mainmute":
            return self._status_key("MAIN", [self._xa("mMute", mute="2")], mute_fbs("lr"), hold=True)
        if act == "duck":
            return self._status_key("DUCK", [self._xa("gate", type="/ch/", num=int(shot), set="2")],
                                    [("ch_gate", dict(theChannel=int(shot), state="1"), ON, ink, "ON"),
                                     ("ch_gate", dict(theChannel=int(shot), state="0"), WARN, ink, "OFF!")],
                                    json.dumps("GATE ON/OFF"))
        sign = 1 if act == "ambup" else -1
        ctl = self._blank()
        ctl["steps"]["0"]["action_sets"]["down"] = [self._xa_step(shot, sign * max(1, int(step)))]
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(self.XAIR_COLOR); l["borderPosition"] = wrap("inside")
            elif l["id"] == "text0":
                l["text"] = wrap("+" if sign > 0 else "−"); l["fontsize"] = wrap(40); l["y"] = wrap(4)
        ctl["style"]["layers"].append(self.text_layer(json.dumps("AMBIENT"), True, -34, 11, self.XAIR_COLOR))
        ctl["style"]["layers"].append(self.text_layer(self._xa_db(label, shot), True, 34, 11, GREY))
        return ctl

    def xair_dial(self, shot, step=1, label="xair"):
        """+ XL encoder on the ambient fader: turn = fader, press = mute. The strip shows the
        dB and goes red with MUTED. The module's fader limit keeps it at or below its Fader Max."""
        step = max(1, int(step))
        strip = self._blank()
        word = self.text_layer("MUTED", False, 22, 13, DARK)
        foot = self.text_layer(json.dumps("TURN = LEVEL, PRESS = MUTE"), True, 22, 11, GREY)
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(strip_art("xairlevel")); l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(self._xa_db(label, shot), True)
                l["fontsize"] = wrap(30); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(0); l["height"] = wrap(100)
        strip["style"]["layers"] += [self.text_layer(json.dumps("AMBIENT"), True, -23, 13, self.XAIR_COLOR), foot, word]
        ov = [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(0xD92B2B)},
              {"overrideId": nid(), "elementId": foot["id"], "elementProperty": "color", "override": wrap(0xD92B2B)},
              {"overrideId": nid(), "elementId": word["id"], "elementProperty": "color", "override": wrap(0xFFFFFF)}]
        strip["feedbacks"] = [self._xa_fb("ch", ov, theChannel=int(shot), state="1")]
        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        knob["steps"]["0"]["action_sets"].update({
            "down": [self._xa("mute", type="/ch/", num=int(shot), mute="2")],
            "rotate_left": [self._xa_step(shot, -step)],
            "rotate_right": [self._xa_step(shot, step)],
        })
        return strip, knob

    # ------------------------------------------------------------ SuperSource controller
    # One page drives a whole SuperSource: BOX 1-4 keys pick the box (press it again to
    # switch between SOURCE and MOVE/SIZE), source keys and the source dial fill the picked
    # box, ON/OFF keys and the BOX dial switch boxes on air, X / Y / SIZE dials move it.
    # Page state lives in custom variables (per SuperSource n):
    #   sbss{n}_box 1-4 · sbss{n}_edit "src"/"pos" · sbss{n}_fine 0/1 · sbss{n}_pick scroll index
    # Actions (bmd-atem 4.3): setSsrcBoxSource, setSsrcBoxEnable {onair toggle},
    # setSsrcBoxProperties {properties[...]}, setSsrcBoxPropertiesDelta {properties[...]}.
    # Live readouts: $(ATEM:ssrc{n}_box{b}_source / _onair / _x / _y / _size).
    SSC_MOVE = 0xFF7A3D           # MOVE/SIZE mode (warm, so it reads apart from SOURCE teal)

    @staticmethod
    def ssc_vars(n):
        return {"box": f"($(custom:sbss{n}_box) ?? 1)", "edit": f'($(custom:sbss{n}_edit) ?? "src")',
                "fine": f"($(custom:sbss{n}_fine) ?? 0)", "pick": f"($(custom:sbss{n}_pick) ?? 1)"}

    @staticmethod
    def _cmp(var, op, val):
        return {"type": "feedback", "id": nid(), "definitionId": "variable_value", "connectionId": "internal",
                "options": {"variable": wrap(f"custom:{var}"), "op": wrap(op), "value": wrap(str(val))},
                "isInverted": wrap(False)}

    @staticmethod
    def _and(conds, overrides=None):
        f = {"type": "feedback", "id": nid(), "definitionId": "logic_operator", "connectionId": "internal",
             "options": {"operation": wrap("and")}, "isInverted": wrap(False), "children": {"default": conds}}
        if overrides:
            f["styleOverrides"] = overrides
        return f

    @staticmethod
    def _iff(cond, then, other=()):
        return {"type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal", "options": {},
                "children": {"condition": [cond], "actions": list(then), "else_actions": list(other)}}

    @staticmethod
    def _fill(fill, text=0x000000, extra=()):
        o = [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(fill)},
             {"overrideId": nid(), "elementId": "text0", "elementProperty": "color", "override": wrap(text)}]
        return o + [{"overrideId": nid(), "elementId": lid, "elementProperty": "color", "override": wrap(text)} for lid in extra]

    def _ssa(self, defn, n, box, **opts):
        """Hand-built bmd-atem SuperSource action (shapes from the 4.3.0 module source)."""
        o = {"ssrcId": wrap(n), "boxIndex": wrap(box, isinstance(box, str))}
        for k, v in opts.items():
            o[k] = v if isinstance(v, dict) and "value" in v else wrap(v)
        return {"type": "action", "id": nid(), "connectionId": self.conn, "definitionId": defn,
                "options": o, "upgradeIndex": 10, "children": {}}

    def _ss_props(self, n, box, props, **vals):
        base = {"transitionRate": 0, "transitionEasing": "linear", "transitionCurve": "ease-in", "size": 0.5,
                "onair": "true", "source": 0, "x": 0, "y": 0, "cropEnable": False,
                "cropTop": 0, "cropBottom": 0, "cropLeft": 0, "cropRight": 0}
        base.update(vals)
        return self._ssa("setSsrcBoxProperties", n, box, properties=list(props), **base)

    def _ss_delta(self, n, box, prop, expr):
        vals = {"size": 0, "x": 0, "y": 0, "cropTop": 0, "cropBottom": 0, "cropLeft": 0, "cropRight": 0}
        vals[prop] = wrap(expr, True)
        return self._ssa("setSsrcBoxPropertiesDelta", n, box, properties=[prop], **vals)

    @staticmethod
    def ssc_live(n, box_expr, suffix):
        """Live value of the picked box: $(ATEM:ssrc{n}_box{b}_{suffix}) chosen by the box variable."""
        out = f"$(ATEM:ssrc{n}_box4_{suffix})"
        for b in (3, 2, 1):
            out = f"({box_expr} == {b} ? $(ATEM:ssrc{n}_box{b}_{suffix}) : {out})"
        return out

    def _ssc_key(self, border, big, big_expr, tag, tag_expr, foot, foot_expr, glyph=True):
        ctl = self._blank()
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(border); l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                if glyph:
                    l["base64Image"] = wrap(self.glyphs["SS"])
                    l["x"], l["y"] = wrap(7), wrap(7)
                    l["width"], l["height"] = wrap(20), wrap(20)
                    l["halign"], l["valign"] = wrap("left"), wrap("top")
                    l["fillMode"] = wrap("fit")
                else:
                    l["enabled"] = wrap(False)
            elif l["id"] == "text0":
                l["text"] = wrap(big, big_expr)
                l["fontsize"] = wrap(28); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(2)
        t = self.text_layer(tag, tag_expr, -37, 12, border, x=9 if glyph else 0)
        f = self.text_layer(foot, foot_expr, 36, 12, GREY)
        ctl["style"]["layers"] += [t, f]
        return ctl, t, f

    def ssc_box_key(self, n, b, hi=20):
        """BOX b: press to pick it (source mode); press again to flip SOURCE <-> MOVE/SIZE."""
        v = self.ssc_vars(n)
        ctl, t, f = self._ssc_key(SS_COLOR, f"$(ATEM:ssrc{n}_box{b}_source)", False, f"BOX {b}", False,
                                  f'{v["box"]} == {b} ? ({v["edit"]} == "pos" ? "MOVE/SIZE" : "SOURCE") : '
                                  f'($(ATEM:ssrc{n}_box{b}_onair) ? "ON" : "OFF")', True)
        sid = f"$(ATEM:ssrc{n}_box{b}_source_id)"
        sync = self._set_var(f"sbss{n}_pick", f"({sid} >= 1 && {sid} <= {int(hi)}) ? {sid} : {v['pick']}")
        ctl["steps"]["0"]["action_sets"]["down"] = [self._iff(
            self._cmp(f"sbss{n}_box", "eq", b),
            [self._set_var(f"sbss{n}_edit", f'{v["edit"]} == "pos" ? "src" : "pos"')],
            [self._set_var(f"sbss{n}_box", str(b)), self._set_var(f"sbss{n}_edit", '"src"'), sync])]
        ctl["feedbacks"] = [
            self._and([self._cmp(f"sbss{n}_box", "eq", b), self._cmp(f"sbss{n}_edit", "ne", "pos")],
                      self._fill(SS_COLOR, 0x000000, (t["id"], f["id"]))),
            self._and([self._cmp(f"sbss{n}_box", "eq", b), self._cmp(f"sbss{n}_edit", "eq", "pos")],
                      self._fill(self.SSC_MOVE, 0x000000, (t["id"], f["id"])))]
        return ctl

    def ssc_onoff_key(self, n, b):
        ctl, t, f = self._ssc_key(SS_COLOR, f"BOX {b}", False, "ON / OFF", False,
                                  f'$(ATEM:ssrc{n}_box{b}_onair) ? "ON AIR" : "OFF"', True, glyph=False)
        ctl["steps"]["0"]["action_sets"]["down"] = [self._ssa("setSsrcBoxEnable", n, b, onair="toggle")]
        fb = {"type": "feedback", "id": nid(), "definitionId": "ssrc_box_enable", "connectionId": self.conn,
              "options": {"ssrcId": wrap(n), "boxIndex": wrap(b)}, "isInverted": wrap(False), "upgradeIndex": 10,
              "styleOverrides": self._fill(SS_COLOR, 0x000000, (t["id"], f["id"]))}
        ctl["feedbacks"] = [fb]
        return ctl

    def ssc_source_key(self, n, inp):
        """Source into the PICKED box (the box variable), lit teal while it is in that box."""
        v = self.ssc_vars(n)
        ctl = self.ss_box_button(n, 1, inp)
        for x in [a for a in ctl["steps"]["0"]["action_sets"]["down"]] + ctl["feedbacks"]:
            if "boxIndex" in x.get("options", {}):
                x["options"]["boxIndex"] = wrap(v["box"], True)
        for l in ctl["style"]["layers"]:
            if l["type"] == "text" and str(l["text"]["value"]).startswith('concat("SS"'):
                l["text"] = wrap(f'concat("INTO BOX ", {v["box"]})', True)
        return ctl

    def ssc_action_key(self, n, act, mes=2):
        """Utility keys: me (cycle the page M/E), pvw/cut/auto (SuperSource n to the page M/E),
        step (fine/coarse dials), center, full."""
        v = self.ssc_vars(n)
        me = "($(custom:sb_me) ?? 1)"
        if act == "me":
            ctl, t, f = self._ssc_key(0x8E6FE6, f'concat("M/E ", {me})', True, "SELECT", False, "page M/E", False, glyph=False)
            ctl["steps"]["0"]["action_sets"]["down"] = [self._set_var("sb_me", f"({me} % {max(1, int(mes))}) + 1")]
            return ctl
        if act in ("pvw", "cut", "auto"):
            if act == "pvw":
                src = self.fresh(next(a for a in self.pvw["steps"]["0"]["action_sets"]["down"] if a["definitionId"] == "preview"))
                src["options"]["mixeffect"] = wrap(me, True)
                src["options"]["input"] = wrap(6000 + n - 1)
                ctl, t, f = self._ssc_key(0x2E90D9, f"SS{n}", False, "TO PVW", False, f'concat("M/E ", {me})', True)
                ctl["steps"]["0"]["action_sets"]["down"] = [src]
                fbs = []
                for fb in self.fresh(self.pvw)["feedbacks"]:
                    fb["options"]["mixeffect"] = wrap(me, True); fb["options"]["input"] = wrap(6000 + n - 1)
                    fbs.append(fb)
                ctl["feedbacks"] = fbs
                return ctl
            ctl = self.transition_button(act.upper(), 1)
            ctl["localVariables"] = []
            for x in ctl["steps"]["0"]["action_sets"]["down"] + ctl["feedbacks"]:
                if "mixeffect" in x.get("options", {}):
                    x["options"]["mixeffect"] = wrap(me, True)
            ctl["style"]["layers"].append(self.text_layer(f'concat("M/E ", {me})', True, -34, 12, 0x9AA4AD))
            return ctl
        if act == "step":
            ctl, t, f = self._ssc_key(0xF5A524, f'{v["fine"]} == 1 ? "FINE" : "COARSE"', True, "DIAL STEP", False,
                                      "press to switch", False, glyph=False)
            ctl["steps"]["0"]["action_sets"]["down"] = [self._set_var(f"sbss{n}_fine", f'1 - {v["fine"]}')]
            ctl["feedbacks"] = [self._and([self._cmp(f"sbss{n}_fine", "eq", 1)], self._fill(0xF5A524, 0x000000, (t["id"], f["id"])))]
            return ctl
        if act == "center":
            ctl, t, f = self._ssc_key(self.SSC_MOVE, "CENTER", False, f'concat("BOX ", {v["box"]})', True, "x 0 · y 0", False)
            ctl["steps"]["0"]["action_sets"]["down"] = [self._ss_props(n, v["box"], ["x", "y"])]
            return ctl
        if act == "full":
            ctl, t, f = self._ssc_key(self.SSC_MOVE, "FULL", False, f'concat("BOX ", {v["box"]})', True, "size 100%", False)
            ctl["steps"]["0"]["action_sets"]["down"] = [self._ss_props(n, v["box"], ["size", "x", "y"], size=1)]
            return ctl
        raise ValueError(f"unknown SuperSource key {act}")

    def _ssc_strip(self, func, head, big, foot):
        color = DIAL_FUNCS[func][1]
        strip = self._blank()
        for l in strip["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
            elif l["id"] == "image0":
                l["base64Image"] = wrap(strip_art(func))
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(big, True)
                l["fontsize"] = wrap(28); l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(0); l["height"] = wrap(100)
        strip["style"]["layers"].append(self.text_layer(head, True, -23, 13, color))
        strip["style"]["layers"].append(self.text_layer(foot, True, 22, 11, GREY))
        knob = self._blank()
        for l in knob["style"]["layers"]:
            if l["id"] == "text0":
                l["text"] = wrap("")
        knob["options"]["rotaryActions"] = True
        return strip, knob

    def ssc_dial(self, n, func, hi=20, extra=()):
        """sscsrc: scroll sources, press = into the picked box · sscx / sscy / sscsize: move or
        size the picked box (only in MOVE/SIZE mode), press = centre / 50% · sscbox: turn to
        pick the box, press = that box on/off."""
        v = self.ssc_vars(n)
        box, pos_mode = v["box"], self._cmp(f"sbss{n}_edit", "eq", "pos")
        if func == "sscsrc":
            extra = list(extra)
            cur = self.scroll_map(v["pick"], hi, extra)
            top = hi + len(extra)
            name = f'parseVariables(concat("$", "(ATEM:short_", {cur}, ")"), concat("IN ", {cur}))'
            strip, knob = self._ssc_strip("sscsrc", f'concat("BOX ", {box}, " SOURCE")', name,
                                          f'concat("NOW ", {self.ssc_live(n, box, "source")}, " · press = put in")')
            put = self._ssa("setSsrcBoxSource", n, box, source=wrap(cur, True))
            strip["steps"]["0"]["action_sets"]["down"] = [put]
            knob["steps"]["0"]["action_sets"].update({
                "down": [self.fresh(put)],
                "rotate_left": [self._set_var(f"sbss{n}_pick", f"max(1, {v['pick']} - 1)")],
                "rotate_right": [self._set_var(f"sbss{n}_pick", f"min({top}, {v['pick']} + 1)")]})
            return strip, knob
        if func == "sscbox":
            strip, knob = self._ssc_strip("sscbox", '"PICK BOX"', f'concat("BOX ", {box})',
                                          f'concat({self.ssc_live(n, box, "source")}, " · ", {self.ssc_live(n, box, "onair")} ? "ON AIR" : "OFF", " · press = on/off")')
            tog = self._ssa("setSsrcBoxEnable", n, box, onair="toggle")
            strip["steps"]["0"]["action_sets"]["down"] = [tog]
            knob["steps"]["0"]["action_sets"].update({
                "down": [self.fresh(tog)],
                "rotate_left": [self._set_var(f"sbss{n}_box", f"max(1, {box} - 1)")],
                "rotate_right": [self._set_var(f"sbss{n}_box", f"min(4, {box} + 1)")]})
            return strip, knob
        prop = {"sscx": "x", "sscy": "y", "sscsize": "size"}[func]
        step = f'({v["fine"]} == 1 ? 0.01 : 0.05)' if prop == "size" else f'({v["fine"]} == 1 ? 0.25 : 2)'
        live = self.ssc_live(n, box, prop)
        shown = f"concat(round({live} * 100), \"%\")" if prop == "size" else f"round({live} * 10) / 10"
        label = {"x": "X", "y": "Y", "size": "SIZE"}[prop]
        head = f'{v["edit"]} == "pos" ? concat("BOX ", {box}, "  {label}") : "{label} · PRESS BOX AGAIN"'
        foot = f'{v["edit"]} == "pos" ? ({v["fine"]} == 1 ? "fine" : "coarse") : "to move / size it"'
        foot = f'concat({foot}, " · press = {"50%" if prop == "size" else "centre"}")'
        strip, knob = self._ssc_strip(func, head, shown, foot)
        reset = self._ss_props(n, box, [prop], **({"size": 0.5} if prop == "size" else {prop: 0}))
        strip["steps"]["0"]["action_sets"]["down"] = [self._iff(pos_mode, [reset])]
        knob["steps"]["0"]["action_sets"].update({
            "down": [self._iff(self.fresh(pos_mode), [self.fresh(reset)])],
            "rotate_left": [self._iff(self.fresh(pos_mode), [self._ss_delta(n, box, prop, f"-{step}")])],
            "rotate_right": [self._iff(self.fresh(pos_mode), [self._ss_delta(n, box, prop, step)])]})
        return strip, knob

    def _ss_on_air(self, bus_fb, ss, box, fill):
        """AND block: SuperSource `ss` is on this bus AND box `box` holds this key's input AND
        the box is enabled - so a camera parked in a hidden box doesn't light the tally."""
        bus = self.fresh(bus_fb)
        bus.pop("styleOverrides", None)
        bus["options"]["input"] = wrap(6000 + ss - 1)                 # SuperSource 1 = input 6000
        src = self.fresh(self.ss_donor["feedback"])
        src.pop("styleOverrides", None); src.pop("disabled", None)
        src["options"] = {"ssrcId": wrap(ss), "boxIndex": wrap(box), "source": wrap("$(local:input)", True)}
        en = self.fresh(src)
        en["definitionId"] = "ssrc_box_enable"
        en["options"] = {"ssrcId": wrap(ss), "boxIndex": wrap(box)}
        return {"type": "feedback", "id": nid(), "definitionId": "logic_operator", "connectionId": "internal",
                "options": {"operation": wrap("and")}, "isInverted": wrap(False),
                "children": {"default": [bus, src, en]},
                "styleOverrides": [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color",
                                    "override": wrap(fill)}]}

    def tally_button(self, inp, mes, preview=True, ss=None, ss_boxes=()):
        """Display-only tally for one source, for a Cue light to mirror: red when
        on program on any listed M/E, green (optional) when in preview on any."""
        mes = sorted({int(m) for m in mes})
        if not mes:
            raise ValueError("a tally key needs at least one M/E")
        ctl = self._blank()
        ctl["localVariables"] = [self._local("input", inp)]
        src = wrap("$(local:input)", True)
        pvw = next(f for f in self.pvw["feedbacks"] if f["definitionId"] == "preview")
        pgm = next(f for f in self.pvw["feedbacks"] if f["definitionId"] == "program")
        fbs = []
        boxes = sorted({int(x) for x in ss_boxes}) if ss and self.ss_donor else []
        for base, on, fill in ((pvw, preview, 0x00FF00), (pgm, True, 0xFF0000)):   # program last: red wins
            if not on:
                continue
            for m in mes:
                f = self.fresh(base)
                f["options"]["mixeffect"] = wrap(m)
                f["options"]["input"] = src
                fbs.append(f)
                for bx in boxes:                         # on air through SuperSource on this M/E
                    bus = self.fresh(base)
                    bus["options"]["mixeffect"] = wrap(m)
                    fbs.append(self._ss_on_air(bus, int(ss), bx, fill))
        ctl["feedbacks"] = fbs
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(TALLY_COLOR)
                l["borderPosition"] = wrap("inside")
            elif l["id"] == "text0":
                l["text"] = wrap("$(ATEM:short_$(local:input))")
                l["fontsize"] = wrap(30)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2)
        layers = ctl["style"]["layers"]
        box = next(l for l in layers if l["id"] == "box0")
        band = copy.deepcopy(box)
        band.update({"id": nid(), "name": "Tally band", "x": wrap(0), "y": wrap(0),
                     "width": wrap(100), "height": wrap(26), "color": wrap(TALLY_BAND),
                     "borderWidth": wrap(0)})
        img = next(l for l in layers if l["id"] == "image0")
        img.update({"enabled": wrap(True), "base64Image": wrap(tally_glyph()),
                    "x": wrap(8), "y": wrap(3), "width": wrap(20), "height": wrap(20),
                    "halign": wrap("left"), "valign": wrap("top"), "fillMode": wrap("fit")})
        layers.insert(layers.index(img), band)          # band under the icon and text
        for l in layers:
            if l["id"] == "text0":
                l["y"] = wrap(8)
        layers.append(self.text_layer("TALLY", False, -37, 13, 0xFFFFFF, x=8))
        summary = "+".join(f"M{m}" for m in mes) + ("" if preview else " PGM")
        if boxes:
            summary += f" · SS{ss} B" + "+".join(map(str, boxes))
        layers.append(self.text_layer(summary, False, 37, 12, GREY))
        return ctl

    def all_button(self, label, inp, mes, auxes, wait_ms=500):
        """One press, many destinations: every selected M/E gets the source in
        preview, then (after wait_ms) an AUTO; every selected AUX is cut to it.
        The source rides the button's local `input`, so a pasted copy retargets."""
        mes = sorted({int(m) for m in mes})
        auxes = sorted({int(a) for a in auxes})
        if not mes and not auxes:
            raise ValueError("an ALL key needs at least one M/E or AUX")
        ctl = self._blank()
        ctl["localVariables"] = [self._local("input", inp)]
        src = wrap("$(local:input)", True)
        acts, fbs = [], []
        for a in auxes:
            act = self.fresh(self.aux_donor["action"]); act.pop("disabled", None)
            act["options"]["aux"] = wrap(a); act["options"]["input"] = src
            acts.append(act)
            fb = self.fresh(self.aux_donor["feedback"]); fb.pop("disabled", None)
            fb["options"]["aux"] = wrap(a); fb["options"]["input"] = src
            for o in fb["styleOverrides"]:
                o["override"] = wrap(AUX_ON if o["elementId"] == "box0" else 0xFFFFFF)
            fbs.append(fb)
        pv = next(x for x in self.pvw["steps"]["0"]["action_sets"]["down"] if x["definitionId"] == "preview")
        auto = next(x for x in self.auto_t["steps"]["0"]["action_sets"]["down"] if x["definitionId"] == "auto")
        pgm = next(f for f in self.pvw["feedbacks"] if f["definitionId"] == "program")
        for m in mes:
            act = self.fresh(pv)
            act["options"]["mixeffect"] = wrap(m); act["options"]["input"] = src
            acts.append(act)
        if mes:
            w = self.fresh(self.wait)
            w["options"]["time"] = wrap(str(int(wait_ms)), True)
            acts.append(w)
            for m in mes:
                act = self.fresh(auto)
                act["options"]["mixeffect"] = wrap(m)
                acts.append(act)
            for m in mes:                       # red last: on air beats routed
                f = self.fresh(pgm)
                f["options"]["mixeffect"] = wrap(m); f["options"]["input"] = src
                fbs.append(f)
        ctl["steps"]["0"]["action_sets"]["down"] = acts
        ctl["feedbacks"] = fbs
        summary = " · ".join(x for x in ("+".join(f"M{m}" for m in mes), "+".join(f"A{a}" for a in auxes)) if x)
        for l in ctl["style"]["layers"]:
            if l["id"] == "box0":
                l["color"] = wrap(DARK)
                l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(ALL_COLOR)
                l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["enabled"] = wrap(True)
                l["base64Image"] = wrap(self.glyphs["ALL"])
                l["x"], l["y"] = wrap(7), wrap(7)
                l["width"], l["height"] = wrap(20), wrap(20)
                l["halign"], l["valign"] = wrap("left"), wrap("top")
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["text"] = wrap(label)
                l["fontsize"] = wrap(22)
                l["fontsizeAllowShrink"] = wrap(True)
                l["y"] = wrap(2)
        ctl["style"]["layers"].append(self.text_layer("ALL", False, -37, 13, ALL_COLOR, x=9))
        ctl["style"]["layers"].append(self.text_layer(summary, False, 36, 11, GREY))
        return ctl

    @staticmethod
    def glyph_uri(name, hexcolor):
        c = int(hexcolor.lstrip("#"), 16)
        im = Image.new("RGBA", (72, 72), (0, 0, 0, 0))
        draw_glyph(ImageDraw.Draw(im), name, (6, 6, 66, 66), rgb(c) + (255,), 8)
        return png_uri(im)

    def mode_button(self, mode, me, inp):
        """Source key from a switching-mode recipe (see BUILTIN_MODES). The built-in recipes
        reproduce the kit's PVW / CUT / AUTO / HOT keys action for action."""
        take = mode.get("take", "preview")
        ctl = self.fresh(self.pvw)
        pv = self.localize(self.fresh(next(a for a in self.pvw["steps"]["0"]["action_sets"]["down"]
                                           if a["definitionId"] == "preview")))
        ms = str(int(mode.get("waitMs") or 0))
        if take == "program":
            acts = [self.localize(self.fresh(self.cut["steps"]["0"]["action_sets"]["down"][0]))]
            ctl["feedbacks"] = [f for f in ctl["feedbacks"] if f["definitionId"] == "program"]
        elif take == "pvw_cut":
            w = self.fresh(self.wait); w["options"]["time"] = wrap(ms, True)
            cut = self.localize(self.fresh(next(a for a in self.cut_t["steps"]["0"]["action_sets"]["down"])))
            acts = [pv, w, cut]
        elif take == "pvw_auto":
            acts = [pv]
            style = mode.get("style")
            if style in TRANSITION_STYLES:
                acts.append({"type": "action", "id": nid(), "connectionId": self.conn, "definitionId": "transitionStyle",
                             "options": {"mixeffect": wrap("$(local:me)", True), "style": wrap(style)}, "upgradeIndex": 10})
                if style != "sting" and mode.get("rate"):      # the module can't set a sting's rate
                    acts.append({"type": "action", "id": nid(), "connectionId": self.conn, "definitionId": "transitionRate",
                                 "options": {"mixeffect": wrap("$(local:me)", True), "style": wrap(style),
                                             "rate": wrap(max(1, min(250, int(mode["rate"]))))}, "upgradeIndex": 10})
            w = self.fresh(self.wait); w["options"]["time"] = wrap(ms, True)
            auto = self.localize(self.fresh(next(a for a in self.auto_t["steps"]["0"]["action_sets"]["down"]
                                                 if a["definitionId"] == "auto")))
            acts += [w, auto]
        else:
            acts = [pv]
        for f in ctl["feedbacks"]:
            self.localize(f)
        ctl["steps"]["0"]["action_sets"]["down"] = acts
        self.set_locals(ctl, me, inp)
        color = int(mode.get("color", "#9aa4ad").lstrip("#"), 16)
        glyph = self.glyph_uri(mode.get("glyph", "PVW"), mode.get("color", "#9aa4ad"))
        layers = ctl["style"]["layers"]
        for l in layers:
            if l["id"] == "box0":
                l["color"] = wrap(DARK); l["borderWidth"] = wrap(4)
                l["borderColor"] = wrap(color); l["borderPosition"] = wrap("inside")
            elif l["id"] == "image0":
                l["base64Image"] = wrap(glyph)
                l["x"], l["y"] = wrap(7), wrap(7)
                l["width"], l["height"] = wrap(22), wrap(22)
                l["halign"], l["valign"] = wrap("left"), wrap("top")
                l["fillMode"] = wrap("fit")
            elif l["id"] == "text0":
                l["fontsize"] = wrap(30); l["fontsizeAllowShrink"] = wrap(True); l["y"] = wrap(2)
        tag = str(mode.get("tag") or "?")[:6]
        layers.append(self.text_layer(f'concat("M", $(local:me), " {tag}")', True, -37, 13, color, x=9))
        layers.append(self.text_layer(INPUT_LABEL_EXPR, True, 36, 13, GREY))
        return ctl

    def title(self, me, mode):
        ctl = self.fresh(self.nav)
        ctl["steps"]["0"]["action_sets"]["down"] = []
        for l in ctl["style"]["layers"]:
            if l["id"] == "image0":
                l["base64Image"] = wrap(title_tile(me, mode))
        return ctl

    def page(self, me, mode):
        controls = {str(r): {} for r in range(6)}
        controls["0"]["0"] = self.fresh(self.nav)
        controls["0"]["1"] = self.title(me, mode)
        controls["0"]["3"] = self.readout("pgm", me)
        controls["0"]["4"] = self.readout("pvw", me)
        controls["0"]["7"] = self.transition_button("CUT", me)
        controls["0"]["8"] = self.transition_button("AUTO", me)
        slots = [(1 + i // 9, i % 9) for i in range(30)]          # IN 1-30: rows 1-4
        slots += [(4, 5), (4, 6), (4, 7), (4, 8)]                  # MP1-4
        slots += [(4, 3), (4, 4)]                                  # SuperSource 1-2
        slots += [(5, 0), (5, 1), (5, 2), (5, 3)]                  # BLK, BARS, COL1, COL2
        for (inp, _), (r, c) in zip(SOURCES, slots):
            controls[str(r)][str(c)] = self.source_button(mode, me, inp)
        ex = self.ex
        return {
            "version": ex["version"], "type": "page", "companionBuild": ex["companionBuild"],
            "page": {"id": nid(), "name": f"ATEM ME{me} {mode}", "controls": controls,
                     "gridSize": ex["page"]["gridSize"]},
            "oldPageNumber": ex["oldPageNumber"],
            "instances": copy.deepcopy(ex["instances"]),
            "connectionCollections": [], "imageLibrary": [], "imageLibraryCollections": [],
        }

    def me_label(self, me):
        ctl = self.title(me, "PVW")
        for l in ctl["style"]["layers"]:
            if l["id"] == "image0":
                l["base64Image"] = wrap(me_tile(me))
        return ctl

    def home(self):
        controls = {str(r): {} for r in range(6)}
        controls["0"]["0"] = self.fresh(self.nav)          # back to the Downstage Menu
        t = self.title(1, "PVW")
        for l in t["style"]["layers"]:
            if l["id"] == "image0":
                l["base64Image"] = wrap(home_icon(big=True))
        controls["0"]["1"] = t
        for me in MES:
            row = controls[str(me)]
            row["0"] = self.me_label(me)
            for i, mode in enumerate(MODES):
                row[str(1 + i)] = self.nav_button(PLACEHOLDER_PAGE, title_tile(me, mode))
            row["6"] = self.readout("pgm", me)
            row["7"] = self.readout("pvw", me)
        ex = self.ex
        return {
            "version": ex["version"], "type": "page", "companionBuild": ex["companionBuild"],
            "page": {"id": nid(), "name": "ATEM HOME", "controls": controls,
                     "gridSize": ex["page"]["gridSize"]},
            "oldPageNumber": ex["oldPageNumber"],
            "instances": copy.deepcopy(ex["instances"]),
            "connectionCollections": [], "imageLibrary": [], "imageLibraryCollections": [],
        }


def home_icon(big=False):
    """Switcher glyph used on the kit pages' back button and the home title."""
    im = Image.new("RGBA", (144, 144), rgb(DARK) + (255,))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([3, 3, 140, 140], radius=18, outline=(255, 255, 255), width=5)
    # mini switcher: two rows of bus keys
    for r, col in ((0, PGM_RED), (1, PVW_GREEN)):
        for c in range(4):
            x, y = 26 + c * 24, 26 + r * 26
            d.rounded_rectangle([x, y, x + 18, y + 18], radius=4,
                                fill=rgb(col) if c == 1 else (70, 76, 84))
    d.text((72, 112), "ATEM" if big else "ATEM HOME", anchor="mm", font=font(26 if big else 19), fill=(255, 255, 255))
    return png_uri(im)


def me_tile(me):
    im = Image.new("RGBA", (144, 144), rgb(DARK) + (255,))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([3, 3, 140, 140], radius=18, outline=(154, 163, 173), width=5)
    d.text((72, 50), "M/E", anchor="mm", font=font(30), fill=(154, 163, 173))
    d.text((72, 96), str(me), anchor="mm", font=font(64), fill=(255, 255, 255))
    return png_uri(im)


# ---------------------------------------------------------------- preview

def preview(page, path, names):
    T, pad = 144, 8
    sheet = Image.new("RGB", (9 * (T + pad) + pad, 6 * (T + pad) + pad + 36), (24, 26, 30))
    sd = ImageDraw.Draw(sheet)
    sd.text((pad, 10), page["page"]["name"] + "  (simulated: IN 1 on PGM, IN 2 on PVW)", fill=(230, 230, 230), font=font(18))
    for r, cols in page["page"]["controls"].items():
        for c, ctl in cols.items():
            im = Image.new("RGBA", (T, T), (0, 0, 0, 255))
            d = ImageDraw.Draw(im)
            lv = {l["variableName"]: l["options"]["startup_value"]["value"] for l in ctl.get("localVariables", [])}
            inp = lv.get("input")
            fill = None
            if inp == 1 and any(f["definitionId"] == "program" for f in ctl["feedbacks"]):
                fill = rgb(0xFF0000)
            elif inp == 2 and any(f["definitionId"] == "preview" for f in ctl["feedbacks"]):
                fill = rgb(0x00FF00)
            for l in ctl["style"]["layers"]:
                t = l["type"]
                if t == "box":
                    d.rectangle([0, 0, T, T], fill=fill or rgb(l["color"]["value"]))
                    bw = l["borderWidth"]["value"]
                    if bw:
                        d.rectangle([0, 0, T - 1, T - 1], outline=rgb(l["borderColor"]["value"]), width=bw * 2)
                elif t == "image":
                    v = l["base64Image"]["value"]
                    if isinstance(v, str) and v.startswith("data:image"):
                        g = Image.open(io.BytesIO(base64.b64decode(v.split(",", 1)[1]))).convert("RGBA")
                        w = int(T * l["width"]["value"] / 100)
                        g = g.resize((w, int(T * l["height"]["value"] / 100)))
                        im.alpha_composite(g, (int(T * l["x"]["value"] / 100), int(T * l["y"]["value"] / 100)))
                elif t == "text" and l["enabled"]["value"]:
                    s = str(l["text"]["value"])
                    me = lv.get("me", 1)
                    if "short_" in s:
                        s = names.get(str(inp), f"IN{inp}")
                    elif "pgm$" in s:
                        s = names.get("1", "IN1")
                    elif "pvw$" in s:
                        s = names.get("2", "IN2")
                    elif s.startswith("concat(\"M\""):
                        s = f"M{me} " + s.split('" ')[-1].split('"')[0].strip()
                        s = f"M{me} {s.split()[-1]}"
                    elif s.startswith("$(local:input)"):
                        s = next(lbl for i, lbl in SOURCES if i == inp)
                    if not s:
                        continue
                    col = (0, 0, 0) if fill == rgb(0x00FF00) and l["id"] == "text0" else rgb(l["color"]["value"])
                    fs = max(12, int(l["fontsize"]["value"] * 1.3))
                    y = T / 2 + T * l["y"]["value"] / 100
                    x = T / 2 + T * l["x"]["value"] / 100
                    d.text((x, y), s, anchor="mm", font=font(fs), fill=col)
            sheet.paste(im.convert("RGB"), (pad + int(c) * (T + pad), 36 + pad + int(r) * (T + pad)))
    sheet.save(path)


def main():
    if len(sys.argv) not in (3, 4):
        sys.exit(__doc__)
    example = json.loads(gzip.decompress(open(sys.argv[1], "rb").read()))
    out = sys.argv[2]
    names = json.load(open(sys.argv[3])) if len(sys.argv) == 4 else {}
    os.makedirs(os.path.join(out, "previews"), exist_ok=True)
    kit = Kit(example)
    pages = [("atem-HOME", kit.home())]
    pages += [(f"atem-ME{me}-{mode}", kit.page(me, mode)) for me in MES for mode in MODES]
    for stem, pg in pages:
        fn = f"{stem}.companionconfig"
        open(os.path.join(out, fn), "wb").write(gzip.compress(json.dumps(pg).encode()))
        preview(pg, os.path.join(out, "previews", f"{stem}.png"), names)
        print("wrote", fn)
    icons = os.path.join(out, "icons")
    os.makedirs(icons, exist_ok=True)

    def save(uri, name):
        open(os.path.join(icons, name), "wb").write(base64.b64decode(uri.split(",", 1)[1]))
    save(home_icon(), "atem-home.png")
    for me in MES:
        save(me_tile(me), f"me{me}.png")
        for mode in MODES:
            save(title_tile(me, mode), f"me{me}-{mode.lower()}.png")
    print("wrote icons/")


if __name__ == "__main__":
    main()
