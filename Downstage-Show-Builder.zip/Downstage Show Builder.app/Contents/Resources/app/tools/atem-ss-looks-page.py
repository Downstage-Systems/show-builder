#!/usr/bin/env python3
"""SuperSource look keys: <n> BOX / FULL 1..n / SETUP (2 BOX / FULL GFX / FULL CAM / SETUP for 2).

    python3 tools/atem-ss-looks-page.py "<... SS ANIM.xml>" [out.companionconfig] [--ss 1] [--count 4]

The ATEM file is the profile written by ATEM SS Builder/ss_anim.py; macro
numbers are looked up there BY NAME ("SS 2BOX>FS1" ...), so the page follows
wherever the macros landed on that switcher. 1-4 picture looks: the 2-box macros
are "SS 2BOX...", the others "SS1 1BOX...", "SS3 3BOX...", "SS4 4BOX..." (one
family per look, so a switcher can hold several); read_macros(count=) picks one.

Hand-in (exports with the "SS IN ..." macros): a key pressed while something other
than SuperSource is on program never dissolves over it. If the graphics source is
live it runs SS IN <gfx>>..., otherwise it first puts whatever is live into the
camera box (setSsrcBoxSource = $(ATEM:pgm<me>_input_id)) and runs SS IN <cam>>...:
SuperSource snaps to that picture full screen off air, program cuts to it (same
picture), then the move runs. A camera M/E feeding the camera box is the same case
(its program is what's live, the box already has it). Camera box, graphics input
and M/E come from the SETUP description ("camera FS2 · gfx 3010 · me 1").

Each look key reads the switcher, not a remembered state:
  - FULL GFX is live when the FS1 picture box is at size 1
  - FULL CAM is live when the FS2 picture box is at size 1 and the FS1 box isn't
  - 2 BOX otherwise
(size only: the module compares x/y as exact floats, size is rounded to 0.01.)
Press = do nothing while any SS move macro is running, do nothing if already
on that look, else run the one macro that goes from the current look to this
one. The lit key always shows what is really on the SuperSource.

bmd-atem 4.x shapes: macrorun {macro: 1-based, action run|runContinue};
feedback macro {macroIndex 1-based, state isRunning}; ssrc_box_properties
{ssrcId, boxIndex 1-based, properties [...], size ...}. No real macro or box-
properties button existed to clone, so these follow the module 4.1.2 option
definitions (main.js) wrapped the 5.0.3 way; the shell (ids, connection,
upgradeIndex 10) is cloned from the ssrc donor. logic_if / logic_operator /
wait shapes come from obsbot-tail2-page.py and atem-me-pages.py.
"""
import copy, gzip, importlib.util, json, os, re, sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("atem_me_pages", os.path.join(HERE, "atem-me-pages.py"))
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
wrap, nid = gen.wrap, gen.nid

EXAMPLE = json.loads(gzip.decompress(open(os.path.join(HERE, "show-builder", "donor-atem-page8.companionconfig"), "rb").read()))
SS_DONOR = json.load(open(os.path.join(HERE, "show-builder", "donor-atem-ssrc.json")))
KIT = gen.Kit(EXAMPLE, ss_donor=SS_DONOR)
CONN = KIT.conn                                   # the One's "ATEM" connection

TEAL, AMBER, GREY = gen.SS_COLOR, 0xF5A524, gen.GREY
PREFIX = {1: "SS1 ", 2: "SS ", 3: "SS3 ", 4: "SS4 "}         # macro name prefix per picture count


def plan(n):
    """(moves, hand-in moves) for an n-picture look, named as ss_anim.py names them."""
    H, FS = f"{n}BOX", [f"FS{i + 1}" for i in range(n)]
    moves = [f"{a}>{b}" for f in FS for a, b in ((H, f), (f, H))] + [f"{a}>{b}" for a in FS for b in FS if a != b]
    ins = [f"IN {a}>{b}" for a in FS for b in [H] + [x for x in FS if x != a]]
    return moves, ins


FLY_PREFIX = "SSF "
me_of = lambda inp: (inp - 10000) // 10 if isinstance(inp, int) and 10010 <= inp < 11000 and inp % 10 == 0 else 0   # M/E program feed                                         # rounded + fly-in looks (no move macros)


def families(path):
    """Look families whose SETUP macro is in this ATEM file: picture counts 1-4 for the animated
    looks, "F1".."F4" for rounded + fly-in looks."""
    names = {m.get("name", "") for m in ET.parse(path).getroot().iter("Macro")}
    return ([n for n, p in PREFIX.items() if f"{p}{n}BOX SETUP" in names] +
            [f"F{n}" for n in range(1, 5) if f"{FLY_PREFIX}{n}BOX SETUP" in names])


def read_fly(path, fam):
    """Rounded + fly-in export: {setup, keys [(keyer, input, side)], rate, fps, me, n, home, names, pics}.
    input is an input id, or ("box", n) for a keyer that follows whatever is in picture box n."""
    n = int(str(fam)[1:])
    root = ET.parse(path).getroot()
    setup = next(m for m in root.iter("Macro") if m.get("name") == f"{FLY_PREFIX}{n}BOX SETUP")
    desc = setup.get("description", "")
    spec = re.search(r"fly ([\db:LR,]+)", desc)
    if not spec:
        sys.exit(f"{path}: the fly SETUP macro has no keyer list - re-export from SuperSource Builder.")
    keys = []
    for part in spec.group(1).split(","):
        k, inp, side = part.split(":")
        keys.append((int(k), ("box", int(inp[1:])) if inp.startswith("b") else int(inp), side))
    num = lambda pat, d: float(re.search(pat, desc).group(1)) if re.search(pat, desc) else d
    names = {int(i.get("id")): i.get("shortName") for i in root.iter("Input") if (i.get("id") or "").isdigit()}
    ease = re.search(r"ease (\w+)", desc)
    pics = re.search(r"pictures ([\d,]+)", desc)
    ins = re.search(r"inputs ([\d,]+)", desc)
    return {"setup": int(setup.get("index")) + 1, "keys": keys, "rate": int(num(r"rate (\d+)", 15)),
            "ease": ease.group(1) if ease else "cubic",
            "fps": num(r"fps ([\d.]+)", 29.97), "me": int(num(r"· me (\d+)", 1)), "n": n, "home": f"{n}BOX",
            "names": names, "pics": [int(x) for x in pics.group(1).split(",")] if pics else list(range(1, n + 1)),
            "inputs": [int(x) for x in ins.group(1).split(",")] if ins else []}


# ---------------------------------------------------------------- ATEM file

def macro_ms(path, macros):
    """{macro name: how long it runs, ms}, from its MacroSleep frames and the profile's video mode."""
    root = ET.parse(path).getroot()
    mode = next((v.get("videoMode", "") for v in root.iter("VideoMode")), "")
    m = re.search(r"[pi](\d+)$", mode)
    fps = {"2398": 23.98, "2997": 29.97, "5994": 59.94}.get(m.group(1), float(m.group(1))) if m else 29.97
    index = {n: i - 1 for n, i in macros.items()}
    out = {n: 1000 for n in macros}
    for x in root.iter("Macro"):
        for n, i in index.items():
            if x.get("index") == str(i):
                out[n] = round(sum(int(o.get("frames", 0)) for o in x if o.get("id") == "MacroSleep") / fps * 1000)
    return out


def read_macros(path, count=None):
    """({'2BOX>FS1': 7, ..., '2BOX SETUP': 6} 1-based macro numbers, [picture boxes], roles).
    roles: n, home, moves, ins, hand (all IN macros present), camera (FS number, 0 = none),
    inputs (home input id per picture, None if unknown), me."""
    fams = families(path)
    if not fams:
        sys.exit(f"{path}: no SuperSource look macros (SS 2BOX SETUP ...) - run ss_anim.py first.")
    n = count if count in fams else (2 if 2 in fams else fams[0])
    prefix, H = PREFIX[n], f"{n}BOX"
    root = ET.parse(path).getroot()
    found = {}
    for m in root.iter("Macro"):
        name = m.get("name", "")
        if name.startswith(prefix):
            found[name[len(prefix):]] = int(m.get("index")) + 1
    moves, ins = plan(n)
    missing = [k for k in moves + [f"{H} SETUP"] if k not in found]
    if missing:
        sys.exit(f"{path}: no macro named {', '.join(prefix + k for k in missing)} - run ss_anim.py first.")
    setup = next(m for m in root.iter("Macro") if m.get("name") == f"{prefix}{H} SETUP")
    desc = setup.get("description", "")
    named = re.search(r"pictures ([\d,]+)", desc)
    if named:                                  # written by ss_anim.py: "... · pictures 1,3" (FS1 box, FS2 box...)
        pics = [int(x) for x in named.group(1).split(",") if x]
    else:                                      # older exports: the boxes fed a real source (plates get Black/Color)
        plate = re.compile(r"^(Black|Color\d+|ColorBars)$")
        pics = [int(op.get("boxIndex")) + 1 for op in setup
                if op.get("id", "").endswith("BoxInput") and not plate.match(op.get("input", ""))]
    roles = {"n": n, "home": H, "moves": moves, "ins": ins, "camera": 0, "inputs": [None] * n, "me": 1}
    m = re.search(r"camera FS(\d)", desc)
    roles["camera"] = int(m.group(1)) if m else 0
    m = re.search(r"inputs ([\d,]+)", desc)
    if m:
        roles["inputs"] = [int(x) for x in m.group(1).split(",")][:n] + [None] * (n - len(m.group(1).split(",")))
    else:
        g = re.search(r"gfx (\d+)", desc)    # first hand-in exports (2 pictures): only the graphics input
        if g and n == 2 and roles["camera"]:
            roles["inputs"][2 - roles["camera"]] = int(g.group(1))
    m = re.search(r"· me (\d+)", desc)
    roles["me"] = int(m.group(1)) if m else 1
    roles["hand"] = bool(all(k in found for k in ins) and m) and bool(
        roles["camera"] or any(v is not None for v in roles["inputs"]))
    if roles["hand"]:
        roles["inputs"] = [None if i + 1 == roles["camera"] else v for i, v in enumerate(roles["inputs"])]
    return found, pics, roles


# ---------------------------------------------------------------- building blocks

def atem_action(definition, **options):
    a = KIT.fresh(SS_DONOR["action"])
    a.pop("disabled", None)
    a["connectionId"] = CONN
    a["definitionId"] = definition
    a["options"] = {k: wrap(v) for k, v in options.items()}
    return a


def atem_fb(definition, **options):
    f = KIT.fresh(SS_DONOR["feedback"])
    f.pop("disabled", None)
    f.pop("styleOverrides", None)
    f["connectionId"] = CONN
    f["definitionId"] = definition
    f["options"] = {k: wrap(v, isinstance(v, str) and "$(" in v) for k, v in options.items()}
    return f


def atem_action_expr(definition, **options):
    """Like atem_action, but string values starting with $( are expressions."""
    a = atem_action(definition)
    a["options"] = {k: wrap(v, isinstance(v, str) and "$(" in v) for k, v in options.items()}
    return a


def on_program(me, inp):
    return atem_fb("program", mixeffect=me, input=inp)


def run_macro(n):
    return atem_action("macrorun", macro=n, action="run")


def box_full(ss, box):
    """True when SuperSource `ss` box `box` (1-based) is at size 1."""
    return atem_fb("ssrc_box_properties", ssrcId=ss, boxIndex=box, properties=["size"], size=1,
                   onair="true", source=0, x=0, y=0, cropEnable=False,
                   cropTop=0, cropBottom=0, cropLeft=0, cropRight=0)


def invert(fb):
    fb = copy.deepcopy(fb)
    fb["isInverted"] = wrap(True)
    return fb


def any_of(fbs):
    return {"type": "feedback", "id": nid(), "definitionId": "logic_operator", "connectionId": "internal",
            "options": {"operation": wrap("or")}, "isInverted": wrap(False), "children": {"default": list(fbs)}}


def all_of(fbs):
    o = any_of(fbs)
    o["options"]["operation"] = wrap("and")
    return o


def logic_if(cond, then, otherwise):
    return {"type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal", "options": {},
            "children": {"condition": [cond], "actions": list(then), "else_actions": list(otherwise)}}


def lit(fb, fill, text=0x000000):
    fb["styleOverrides"] = [
        {"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(fill)},
        {"overrideId": nid(), "elementId": "text0", "elementProperty": "color", "override": wrap(text)}]
    return fb


def key(label, color, tag, sub=None, label_expr=False):
    ctl = KIT._blank()
    for l in ctl["style"]["layers"]:
        if l["id"] == "box0":
            l["color"] = wrap(gen.DARK)
            l["borderWidth"] = wrap(4)
            l["borderColor"] = wrap(color)
            l["borderPosition"] = wrap("inside")
        elif l["id"] == "text0":
            l["text"] = wrap(label, label_expr)
            l["fontsize"] = wrap(22)
            l["fontsizeAllowShrink"] = wrap(True)
            l["y"] = wrap(4)
    ctl["style"]["layers"].append(KIT.text_layer(tag, False, -37, 12, color))
    if sub:
        ctl["style"]["layers"].append(KIT.text_layer(sub, sub.startswith(("$(", "concat(")), 36, 11, GREY))
    return ctl


# ---------------------------------------------------------------- page

def wait(ms):
    w = KIT.fresh(KIT.wait)
    w["options"]["time"] = wrap(str(int(ms)), True)
    return w


def fly_controls(atem_file, ss=1, fam="F2"):
    """Rounded + fly-in keys. The boxes never move; each keyer holds one full-frame source on a DVE.
    FULL <src>: (nothing while a fly key is on air, or if it's already live) key to its off-frame side,
    on air, slide to full frame, wait, cut program to that source underneath (no change), key off.
    <n> BOX: the keyer whose source is live (else keyer 1 with its fill set to whatever is live) on at
    full frame, cut program to SuperSource underneath, slide off its side, wait, key off.
    The slide is Companion's eased DVE move (uskDveProperties transitionRate / transitionEasing /
    transitionCurve ease-in-out) - smooth only with the ATEM connection's "Framerate for fades" at 30-60
    (default 10). The switcher's own fly (keyframes A/B, stored by SETUP) has no easing.
    SETUP: every keyer to DVE type, its source, keyframes B = full frame and A = off its side, off air;
    then the SuperSource SETUP macro. Keyframes / DVE shapes: bmd-atem 4.1.2 (uskType, uskSource,
    uskDveProperties, uskStoreKeyframe, uskFly, uskOnAir; mixeffect and key 1-based)."""
    f = read_fly(atem_file, fam)
    me, H = f["me"], f["home"]
    # a keyer tied to a box takes whatever that box shows right now - change the box's camera and the
    # fly-in follows ($(ATEM:ssrc<n>_box<b>_source_id), the SuperSource box the picture sits in)
    box_of = lambda inp: f["pics"][inp[1] - 1] if isinstance(inp, tuple) and inp[1] <= len(f["pics"]) else None
    live_src = lambda inp: f"$(ATEM:ssrc{ss}_box{box_of(inp)}_source_id)" if isinstance(inp, tuple) else inp
    keys = [(k, live_src(inp), side, inp) for k, inp, side in f["keys"]]
    ms = round(f["rate"] / f["fps"] * 1000) + 120                # the fly, plus a few frames' margin
    usk = lambda k, d, **o: atem_action_expr(d, mixeffect=me, key=k, **o)
    off_x = lambda side: -32 if side == "L" else 32               # one frame width off that side
    EASE = {"cubic": "cubic", "sine": "sinusoidal", "quad": "quadratic", "linear": "linear"}.get(f["ease"], "cubic")
    def at(k, x, rate=0):                                         # put the key there (rate ms > 0: eased slide)
        return usk(k, "uskDveProperties", **{**gen.DVE_DEFAULTS, "properties": ["positionX", "positionY", "sizeX", "sizeY"],
                   "positionX": x, "positionY": 0, "sizeX": 1, "sizeY": 1, "transitionRate": rate,
                   "transitionEasing": EASE if rate else "linear", "transitionCurve": "ease-in-out"})
    slide = lambda k, x: at(k, x, round(f["rate"] / f["fps"] * 1000))
    settle = 80                                                   # let Companion see the key's start position first
    onair = lambda k, v: usk(k, "uskOnAir", onair="true" if v else "false")
    pgm = lambda inp: atem_action_expr("program", mixeffect=me, input=inp)
    busy = lambda: any_of([atem_fb("uskOnAir", mixeffect=me, key=k) for k, _, _, _ in keys])
    on_ss = lambda: on_program(me, 6000 + ss - 1)
    SS = 6000 + ss - 1

    def fly_in(k, inp, side):
        return [logic_if(busy(), [], [logic_if(on_program(me, inp), [],
                [usk(k, "uskSource", fill=inp, cut=inp), at(k, off_x(side)), onair(k, True), wait(settle), slide(k, 0),
                 wait(ms), pgm(inp), onair(k, False)])])]

    def fly_out():
        k0, inp0, side0, _ = keys[0]
        chain = [usk(k0, "uskSource", fill=f"$(ATEM:pgm{me}_input_id)", cut=f"$(ATEM:pgm{me}_input_id)"),
                 at(k0, 0), onair(k0, True), pgm(SS), wait(settle), slide(k0, off_x(side0)), wait(ms), onair(k0, False),
                 usk(k0, "uskSource", fill=inp0, cut=inp0)]
        for k, inp, side, _ in reversed(keys):
            chain = [logic_if(on_program(me, inp), [at(k, 0), onair(k, True), pgm(SS), wait(settle), slide(k, off_x(side)), wait(ms), onair(k, False)], chain)]
        return [logic_if(busy(), [], [logic_if(on_ss(), [], chain)])]

    def look_key(label, sub, actions, live):
        ctl = key(label, TEAL, "SS FLY", sub, label_expr=label.startswith("concat("))
        ctl["steps"]["0"]["action_sets"]["down"] = actions
        ctl["feedbacks"] = [lit(live, TEAL), lit(busy(), AMBER)]
        return ctl

    out = {H: look_key(f"{f['n']} BOX", "ROUNDED", fly_out(), all_of([on_ss(), invert(busy())]))}
    for k, inp, side, spec in keys:
        frm = f"KEY {k} · FROM {'LEFT' if side == 'L' else 'RIGHT'}"
        if isinstance(spec, tuple):
            src_in = (f["inputs"] + [None] * 4)[spec[1] - 1]
            shown = f"$(ATEM:pgm{me_of(src_in)}_input)" if me_of(src_in) else f"$(ATEM:ssrc{ss}_box{box_of(spec)}_source)"
            label, frm = f'concat("FULL ", {shown})', f"BOX {spec[1]} · " + frm
        else:
            label = f"FULL {f['names'].get(inp) or f'IN {inp}'}"
        out[f"K{k}"] = look_key(label, frm,
                                fly_in(k, inp, side), all_of([on_program(me, inp), invert(busy())]))
    setup = key("SETUP", GREY, "SS FLY", "KEYS + LOOK")
    acts = []
    for k, inp, side, _ in keys:
        acts += [usk(k, "uskType", type="dve"), usk(k, "uskSource", fill=inp, cut=inp),
                 usk(k, "uskDveProperties", **{**gen.DVE_DEFAULTS, "properties": ["positionX", "positionY", "sizeX", "sizeY", "rate",
                                                                               "maskEnabled", "borderEnabled", "shadowEnabled"],
                     "positionX": 0, "positionY": 0, "sizeX": 1, "sizeY": 1, "rate": f["rate"], "maskEnabled": False,
                     "borderEnabled": False, "shadowEnabled": False}),
                 usk(k, "uskStoreKeyframe", keyframe="b"), at(k, off_x(side)), usk(k, "uskStoreKeyframe", keyframe="a"),
                 onair(k, False)]
    setup["steps"]["0"]["action_sets"]["down"] = acts + [run_macro(f["setup"])]
    out["SETUP"] = setup
    return out, {f"{H} SETUP": f["setup"]}, list(range(1, f["n"] + 1))


def look_controls(atem_file, ss=1, count=None):
    """{'<n>BOX'|'FS1'..'FSn'|'SETUP': control} for one SuperSource Builder export - the smart keys,
    also used by the Show Builder (kind 'sslook'). Fresh ids on every call. Returns (keys, macros, pics);
    keys is ordered home, FS1..FSn, SETUP. A rounded + fly-in export ("F2"...) gives fly_controls()."""
    fams = families(atem_file)
    if str(count).startswith("F") or (count is None and fams and all(str(x).startswith("F") for x in fams)):
        return fly_controls(atem_file, ss, count if str(count).startswith("F") else fams[0])
    macros, pics, roles = read_macros(atem_file, count)
    n, H = roles["n"], roles["home"]
    if len(pics) != n:
        sys.exit(f"expected {n} picture boxes in the SETUP macro, found {pics}")
    FS = [f"FS{i + 1}" for i in range(n)]
    box_of = dict(zip(FS, pics))

    def full(f):
        """This picture fills the frame: its box at size 1 and no higher layer (lower box number) at size 1."""
        above = [invert(box_full(ss, b)) for b in sorted(pics) if b < box_of[f]]
        return all_of([box_full(ss, box_of[f])] + above) if above else box_full(ss, box_of[f])

    busy = lambda: any_of([atem_fb("macro", macroIndex=macros[m], state="isRunning")
                           for m in roles["moves"] + (roles["ins"] if roles["hand"] else [])])
    run = lambda name: [run_macro(macros[name])] if name else []
    route = lambda a, b: f"{a}>{b}" if a != b else None
    hand, cam, me = roles["hand"], roles["camera"], roles["me"]
    cam_fs = f"FS{cam}" if cam else None
    fixed = [(f, roles["inputs"][i]) for i, f in enumerate(FS) if f != cam_fs and roles["inputs"][i] is not None]
    on_ss = lambda: on_program(me, 6000 + ss - 1)
    on_input = lambda inp: on_program(me, inp)

    # Tally: the switcher can't see that a box is covered, so a camera behind a full-screen picture still
    # reads as live. Once a FULL move lands, the boxes nobody can see go off (tally keys and the switcher
    # both go by box on/off); any later move turns them back on first, exactly where the macro left them.
    box_on = lambda b, on: atem_action_expr("setSsrcBoxEnable", ssrcId=ss, boxIndex=b, onair="true" if on else "false")
    move_ms = macro_ms(atem_file, macros)

    def go(name, target):
        if not name:
            return []
        acts = [box_on(b, True) for b in pics] + run(name)
        if target in box_of:                      # still that look when the wait ends (and no new move started)
            acts += [wait(move_ms[name] + 120),
                     logic_if(all_of([full(target), invert(busy())]),
                              [box_on(b, False) for b in pics if b != box_of[target]], [])]
        return acts

    def press(target):
        """Do nothing while a move runs. SuperSource on program: the macro from the live look. Otherwise
        hand in: a fixed picture's source live -> SS IN FSj>target; anything else -> into the camera box."""
        chain = go(route(H, target), target)
        for f in reversed(FS):
            chain = [logic_if(full(f), go(route(f, target), target), chain)]
        if not hand:
            return [logic_if(busy(), [], chain)]
        rest = take_live() + go(f"IN {cam_fs}>{target}", target) if cam_fs and cam_fs != target else []
        for f, inp in reversed(fixed):
            rest = [logic_if(on_input(inp), go(f"IN {f}>{target}" if f != target else None, target), rest)]
        return [logic_if(busy(), [], [logic_if(on_ss(), chain, rest)])]

    def take_live():
        return [atem_action_expr("setSsrcBoxSource", ssrcId=ss, boxIndex=box_of[cam_fs],
                                 source=f"$(ATEM:pgm{me}_input_id)")]

    def look_key(label, sub, actions, live):
        ctl = key(label, TEAL, "SS LOOK", sub, label_expr=label.startswith("concat("))
        ctl["steps"]["0"]["action_sets"]["down"] = actions
        ctl["feedbacks"] = [lit(live, TEAL), lit(busy(), AMBER)]
        return ctl

    src = lambda box: f'$(ATEM:ssrc{ss}_box{box}_source)'
    home_on = all_of([invert(box_full(ss, b)) for b in pics])
    live = {H: all_of([on_ss(), home_on]) if hand else home_on}
    for f in FS:
        if not hand:
            live[f] = full(f)
        elif f == cam_fs:
            live[f] = any_of([all_of([on_ss(), full(f)]), all_of([invert(on_ss())] + [invert(on_input(i)) for _, i in fixed])])
        else:
            inp = dict(fixed).get(f)
            live[f] = any_of([all_of([on_ss(), full(f)])] + ([on_input(inp)] if inp is not None else []))

    def sub(f):
        if hand and f == cam_fs:
            return "CAMERA · LIVE"
        if hand and n == 2 and cam_fs:
            return "GRAPHICS"
        return f"BOX {box_of[f]}"

    keys = {H: look_key(f"{n} BOX", "SIDE BY SIDE" if n == 2 else "HOME LOOK", press(H), live[H])}
    for i, f in enumerate(FS):
        m = me_of((roles["inputs"] + [None] * 4)[i]) if not (cam_fs == f) else 0
        shown = f"$(ATEM:pgm{m}_input)" if m else src(box_of[f])         # a camera M/E: name the camera on it
        keys[f] = look_key(f'concat("FULL ", {shown})', sub(f) if not m else f"M/E {m} · BOX {box_of[f]}", press(f), live[f])
    setup = key("SETUP", GREY, "SS LOOK", f"RESET {n} BOX")
    setup["steps"]["0"]["action_sets"]["down"] = [run_macro(macros[f"{H} SETUP"])]
    keys["SETUP"] = setup
    return keys, macros, pics


def camera_boxes(atem_file, count=None):
    """(SuperSource boxes that get a row of camera keys, [camera input ids]). Fly-in looks: every box a fly key
    follows; animated looks: the camera box (else the last picture). Cameras = the switcher's own inputs."""
    root = ET.parse(atem_file).getroot()
    cams = sorted(int(i.get("id")) for i in root.iter("Input") if (i.get("id") or "").isdigit() and 1 <= int(i.get("id")) < 100)
    fams = families(atem_file)
    fly = str(count).startswith("F") or (count is None and fams and all(str(x).startswith("F") for x in fams))
    if fly:
        f = read_fly(atem_file, count if str(count).startswith("F") else fams[0])
        pics, ins = f["pics"], f["inputs"]
        idx = [inp[1] - 1 for _, inp, _ in f["keys"] if isinstance(inp, tuple) and inp[1] <= len(pics)]
    else:
        _, pics, roles = read_macros(atem_file, count)
        ins = roles["inputs"]
        via_me = [i for i, v in enumerate(ins) if me_of(v)]
        idx = via_me or ([roles["camera"] - 1] if roles.get("camera") else [len(pics) - 1])
    ins = list(ins) + [None] * 4
    # (SuperSource box, M/E): a box fed by an M/E program gets that M/E's program keys instead of box-source keys
    return list(dict.fromkeys((pics[i], me_of(ins[i])) for i in idx)), cams


def build(atem_file, ss=1, count=None):
    """Row 1: the look keys. Rows 2+: one row per camera box - a key per camera that cuts it into that box
    (KIT.ss_box_button: setSsrcBoxSource, lit while the box shows it). A hard cut inside the box."""
    ctl, macros, pics = look_controls(atem_file, ss, count)
    c = {"0": {str(i): v for i, v in enumerate(ctl.values())}}
    cols = EXAMPLE["page"]["gridSize"]["maxColumn"] + 1
    boxes, cams = camera_boxes(atem_file, count)
    for r, (box, me) in enumerate(boxes[:EXAMPLE["page"]["gridSize"]["maxRow"]], start=1):
        # a box fed by an M/E: cut the camera on that M/E's program (the box follows); else put it in the box
        c[str(r)] = {str(i): KIT.source_button("CUT", me, inp) if me else KIT.ss_box_button(ss, box, inp)
                     for i, inp in enumerate(cams[:cols])}
    page = {"version": EXAMPLE["version"], "type": "page", "companionBuild": EXAMPLE["companionBuild"],
            "page": {"id": nid(), "name": "SS LOOKS", "controls": c, "gridSize": EXAMPLE["page"]["gridSize"]},
            "oldPageNumber": 1, "instances": {CONN: EXAMPLE["instances"][CONN]},
            "connectionCollections": [], "imageLibrary": [], "imageLibraryCollections": []}
    return page, macros, pics


if __name__ == "__main__":
    args = sys.argv[1:]
    ss, count = 1, None
    for flag in ("--ss", "--count"):
        if flag in args:
            i = args.index(flag)
            v = int(args[i + 1])
            del args[i:i + 2]
            ss, count = (v, count) if flag == "--ss" else (ss, v)
    if not args:
        sys.exit(__doc__)
    atem_file = args[0]
    out = args[1] if len(args) > 1 else os.path.join(os.path.dirname(HERE), "ss-looks", "atem-ss-looks-v1.companionconfig")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    page, macros, pics = build(atem_file, ss, count)
    open(out, "wb").write(gzip.compress(json.dumps(page).encode()))
    print(f"SuperSource {ss}: " + ", ".join(f"FS{i + 1} picture = box {b}" for i, b in enumerate(pics)))
    print("macros: " + ", ".join(f"{k} #{v}" for k, v in sorted(macros.items(), key=lambda kv: kv[1])))
    print(f"wrote {out}")
